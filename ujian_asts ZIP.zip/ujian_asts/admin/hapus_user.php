<?php

session_start();

require_once "../config/koneksi.php";
require_once "../config/fonnte.php";

if (!isset($_SESSION['login'])) {
    header("Location: ../login.php");
    exit;
}

if ($_SESSION['role'] !== 'admin') {
    header("Location: ../dashboard.php");
    exit;
}

$id = intval($_GET['id'] ?? 0);

if ($id <= 0) {
    $_SESSION['notif'] = "ID user tidak valid.";
    header("Location: users.php");
    exit;
}

/*
|--------------------------------------------------------------------------
| Jangan hapus akun sendiri
|--------------------------------------------------------------------------
*/

if ($id == $_SESSION['id']) {
    $_SESSION['notif'] =
        "Akun yang sedang digunakan tidak dapat dihapus.";

    header("Location: users.php");
    exit;
}


/*
|--------------------------------------------------------------------------
| AMBIL DATA USER
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    SELECT
        id,
        name,
        email,
        no_hp,
        role
    FROM users
    WHERE id = ?
    LIMIT 1
");

$stmt->bind_param("i", $id);
$stmt->execute();

$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {

    $_SESSION['notif'] =
        "Data user tidak ditemukan.";

    header("Location: users.php");
    exit;
}


/*
|--------------------------------------------------------------------------
| SIMPAN DATA SEBELUM DIHAPUS
|--------------------------------------------------------------------------
*/

$nama  = $user['name'];
$email = $user['email'];
$no_hp = trim($user['no_hp'] ?? '');
$role  = $user['role'];


/*
|--------------------------------------------------------------------------
| NORMALISASI NOMOR WHATSAPP
|--------------------------------------------------------------------------
*/

if ($no_hp !== '') {

    // Hilangkan spasi, strip, dan karakter lainnya
    $no_hp = preg_replace('/[^0-9]/', '', $no_hp);

    // 082xxxx -> 6282xxxx
    if (substr($no_hp, 0, 1) === '0') {
        $no_hp = '62' . substr($no_hp, 1);
    }

    // +628xxxx -> 628xxxx
    if (substr($no_hp, 0, 1) === '+') {
        $no_hp = substr($no_hp, 1);
    }
}


/*
|--------------------------------------------------------------------------
| PESAN WHATSAPP
|--------------------------------------------------------------------------
*/

$pesan =
    "🔔 NOTIFIKASI UJIAN ASTS\n\n" .
    "Halo " . $nama . ",\n\n" .
    "Akun Anda telah dihapus dari sistem Ujian ASTS.\n\n" .
    "Detail akun:\n" .
    "Nama: " . $nama . "\n" .
    "Email: " . $email . "\n" .
    "Role: " . strtoupper($role) . "\n\n" .
    "Waktu: " . date('d-m-Y H:i:s') . "\n\n" .
    "Jika Anda merasa akun ini dihapus tanpa izin, silakan hubungi administrator.";


/*
|--------------------------------------------------------------------------
| KIRIM WA TERLEBIH DAHULU
|--------------------------------------------------------------------------
*/

$hasilWA = null;

if ($no_hp !== '') {

    $hasilWA = kirimWhatsApp(
        $no_hp,
        $pesan
    );

}


/*
|--------------------------------------------------------------------------
| HAPUS DATABASE SETELAH WA DIPROSES
|--------------------------------------------------------------------------
*/

$hapus = $conn->prepare("
    DELETE FROM users
    WHERE id = ?
");

$hapus->bind_param("i", $id);

if (!$hapus->execute()) {

    $_SESSION['notif'] =
        "Gagal menghapus akun " . $nama . ".";

    header("Location: users.php");
    exit;
}


/*
|--------------------------------------------------------------------------
| NOTIF WEBSITE
|--------------------------------------------------------------------------
*/

$_SESSION['notif'] =
    "Akun " . $nama . " telah dihapus.";


/*
|--------------------------------------------------------------------------
| SIMPAN STATUS FONNTE
|--------------------------------------------------------------------------
*/

$_SESSION['wa_delete_status'] = $hasilWA;


header("Location: users.php");
exit;