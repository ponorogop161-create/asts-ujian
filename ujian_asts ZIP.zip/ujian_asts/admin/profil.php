<?php

session_start();

if (!isset($_SESSION['login'])) {
    header("Location: ../login.php");
    exit;
}

if ($_SESSION['role'] !== 'admin') {
    header("Location: ../dashboard.php");
    exit;
}

require_once "../config/koneksi.php";

$id = $_SESSION['id'];

$stmt = $conn->prepare("
    SELECT
        id,
        name,
        nisn,
        ttl,
        gender,
        email,
        no_hp,
        role,
        address,
        created_at
    FROM users
    WHERE id = ?
    LIMIT 1
");

$stmt->bind_param("i", $id);
$stmt->execute();

$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    session_destroy();
    header("Location: ../login.php");
    exit;
}

?>

<!DOCTYPE html>
<html lang="id">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Profil Admin - Ujian ASTS</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f1f5f7;
    color: #102530;
}

/* =========================
   SIDEBAR
========================= */

.sidebar {
    position: fixed;
    left: 0;
    top: 0;
    bottom: 0;
    width: 250px;
    background: #0b6e6e;
    color: white;
    padding: 25px 18px;
}

.logo {
    text-align: center;
    font-size: 25px;
    font-weight: bold;
    margin-bottom: 35px;
}

.logo span {
    display: block;
    font-size: 40px;
    margin-bottom: 8px;
}

.logo small {
    display: block;
    font-size: 12px;
    opacity: .75;
    margin-top: 5px;
}

.nav a {
    display: block;
    color: white;
    text-decoration: none;
    padding: 13px 15px;
    border-radius: 9px;
    margin-bottom: 8px;
    transition: .2s;
}

.nav a:hover,
.nav a.active {
    background: rgba(255,255,255,.15);
}

.logout {
    position: absolute;
    left: 18px;
    right: 18px;
    bottom: 25px;
    background: #a4262c;
}

.logout:hover {
    background: #8f2026 !important;
}

/* =========================
   CONTENT
========================= */

.main {
    margin-left: 250px;
    padding: 30px;
}

.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
}

.header h1 {
    margin: 0;
    font-size: 28px;
}

.header p {
    margin: 6px 0 0;
    color: #71828a;
}

.admin-info {
    background: white;
    padding: 12px 18px;
    border-radius: 10px;
    box-shadow: 0 5px 20px rgba(0,0,0,.05);
}

.badge {
    background: #e0f0ee;
    color: #0b6e6e;
    padding: 5px 10px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: bold;
}

/* =========================
   PROFILE
========================= */

.profile-grid {
    display: grid;
    grid-template-columns: 280px 1fr;
    gap: 20px;
}

.card {
    background: white;
    border-radius: 15px;
    padding: 25px;
    box-shadow: 0 5px 20px rgba(0,0,0,.05);
}

.profile-left {
    text-align: center;
}

.avatar {
    width: 105px;
    height: 105px;
    margin: 0 auto 18px;
    border-radius: 50%;
    background: #e0f0ee;
    color: #0b6e6e;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 48px;
}

.profile-left h2 {
    margin: 0;
    font-size: 21px;
}

.profile-left p {
    margin: 7px 0;
    color: #71828a;
}

.role-badge {
    display: inline-block;
    margin-top: 10px;
    background: #e0f0ee;
    color: #0b6e6e;
    padding: 7px 14px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: bold;
}

.profile-date {
    margin-top: 22px;
    padding-top: 18px;
    border-top: 1px solid #edf1f3;
    color: #71828a;
    font-size: 13px;
}

.profile-right {
    padding: 25px;
}

.profile-title {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-bottom: 18px;
    border-bottom: 1px solid #e5ebee;
    margin-bottom: 5px;
}

.profile-title h2 {
    margin: 0;
    font-size: 19px;
}

.btn-edit {
    display: inline-block;
    padding: 9px 15px;
    background: #0b6e6e;
    color: white;
    text-decoration: none;
    border-radius: 8px;
    font-weight: bold;
    font-size: 14px;
}

.btn-edit:hover {
    background: #095a5a;
}

.data-row {
    display: grid;
    grid-template-columns: 180px 1fr;
    padding: 16px 0;
    border-bottom: 1px solid #edf1f3;
}

.data-row:last-child {
    border-bottom: 0;
}

.data-label {
    color: #71828a;
    font-size: 14px;
}

.data-value {
    font-weight: 600;
    color: #263b45;
    word-break: break-word;
}

.role-admin {
    background: #e0f0ee;
    color: #0b6e6e;
    padding: 5px 10px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: bold;
}

.status {
    background: #e8f7ed;
    color: #218838;
    padding: 5px 10px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: bold;
}

/* =========================
   QUICK MENU
========================= */

.quick-menu {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 15px;
    margin-top: 20px;
}

.quick-menu a {
    background: white;
    padding: 18px;
    border-radius: 12px;
    text-decoration: none;
    color: #102530;
    box-shadow: 0 5px 20px rgba(0,0,0,.05);
    transition: .2s;
}

.quick-menu a:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(0,0,0,.08);
}

.quick-icon {
    font-size: 25px;
    margin-bottom: 8px;
}

.quick-title {
    font-weight: bold;
    font-size: 14px;
}

.quick-desc {
    color: #71828a;
    font-size: 12px;
    margin-top: 4px;
}

/* =========================
   RESPONSIVE
========================= */

@media(max-width:900px) {

    .sidebar {
        width: 210px;
    }

    .main {
        margin-left: 210px;
    }

    .profile-grid {
        grid-template-columns: 1fr;
    }

    .quick-menu {
        grid-template-columns: 1fr;
    }
}

@media(max-width:650px) {

    .sidebar {
        position: static;
        width: 100%;
        padding-bottom: 20px;
    }

    .main {
        margin-left: 0;
        padding: 20px;
    }

    .logout {
        position: static;
        margin-top: 20px;
    }

    .header {
        display: block;
    }

    .admin-info {
        margin-top: 15px;
    }

    .data-row {
        grid-template-columns: 1fr;
        gap: 5px;
    }

    .profile-title {
        display: block;
    }

    .btn-edit {
        display: inline-block;
        margin-top: 12px;
    }
}

</style>

</head>

<body>


<!-- =========================
     SIDEBAR
========================= -->

<aside class="sidebar">

    <div class="logo">

        <span>🛡️</span>

        Ujian ASTS

        <small>Admin Panel</small>

    </div>


    <nav class="nav">

        <a href="dashboard.php">
            🏠 Dashboard
        </a>

        <a href="users.php">
            👥 Data User
        </a>

        <a href="tambah_user.php">
            ➕ Tambah User
        </a>

        <a href="profil.php" class="active">
            📋 Profil Saya
        </a>

        <a href="../logout.php" class="logout">
            🚪 Logout
        </a>

    </nav>

</aside>


<!-- =========================
     MAIN
========================= -->

<main class="main">


    <!-- HEADER -->

    <div class="header">

        <div>

            <h1>
                Profil Saya
            </h1>

            <p>
                Informasi akun administrator Ujian ASTS.
            </p>

        </div>


        <div class="admin-info">

            👋

            <strong>
                <?= htmlspecialchars($_SESSION['username']) ?>
            </strong>

            <span class="badge">
                ADMIN
            </span>

        </div>

    </div>


    <!-- PROFILE -->

    <div class="profile-grid">


        <!-- KARTU KIRI -->

        <div class="card profile-left">

            <div class="avatar">
                👤
            </div>


            <h2>
                <?= htmlspecialchars($user['name']) ?>
            </h2>


            <p>
                <?= htmlspecialchars($user['email']) ?>
            </p>


            <span class="role-badge">
                ADMINISTRATOR
            </span>


            <div class="profile-date">

                Bergabung sejak

                <br>

                <strong>
                    <?= date(
                        'd F Y',
                        strtotime($user['created_at'])
                    ) ?>
                </strong>

            </div>

        </div>


        <!-- KARTU KANAN -->

        <div class="card profile-right">

            <div class="profile-title">

                <h2>
                    Informasi Akun
                </h2>

                <a
                    href="edit_user.php?id=<?= $user['id'] ?>"
                    class="btn-edit"
                >
                    ✏️ Edit Profil
                </a>

            </div>


            <div class="data-row">

                <div class="data-label">
                    Nama Lengkap
                </div>

                <div class="data-value">
                    <?= htmlspecialchars($user['name']) ?>
                </div>

            </div>


            <div class="data-row">

                <div class="data-label">
                    NISN
                </div>

                <div class="data-value">
                    <?= htmlspecialchars($user['nisn']) ?>
                </div>

            </div>


            <div class="data-row">

                <div class="data-label">
                    Tempat, Tanggal Lahir
                </div>

                <div class="data-value">
                    <?= htmlspecialchars($user['ttl']) ?>
                </div>

            </div>


            <div class="data-row">

                <div class="data-label">
                    Jenis Kelamin
                </div>

                <div class="data-value">
                    <?= htmlspecialchars($user['gender']) ?>
                </div>

            </div>


            <div class="data-row">

                <div class="data-label">
                    Email
                </div>

                <div class="data-value">
                    <?= htmlspecialchars($user['email']) ?>
                </div>

            </div>


            <div class="data-row">

                <div class="data-label">
                    No. HP
                </div>

                <div class="data-value">

                    <?= !empty($user['no_hp'])
                        ? htmlspecialchars($user['no_hp'])
                        : 'Belum diisi'
                    ?>

                </div>

            </div>


            <div class="data-row">

                <div class="data-label">
                    Alamat
                </div>

                <div class="data-value">
                    <?= htmlspecialchars($user['address']) ?>
                </div>

            </div>


            <div class="data-row">

                <div class="data-label">
                    Role
                </div>

                <div class="data-value">

                    <span class="role-admin">
                        ADMIN
                    </span>

                </div>

            </div>


            <div class="data-row">

                <div class="data-label">
                    Status Akun
                </div>

                <div class="data-value">

                    <span class="status">
                        ✓ Aktif
                    </span>

                </div>

            </div>

        </div>

    </div>


    <!-- MENU CEPAT -->

    <div class="quick-menu">

        <a href="dashboard.php">

            <div class="quick-icon">
                🏠
            </div>

            <div class="quick-title">
                Dashboard
            </div>

            <div class="quick-desc">
                Kembali ke halaman dashboard admin.
            </div>

        </a>


        <a href="users.php">

            <div class="quick-icon">
                👥
            </div>

            <div class="quick-title">
                Data User
            </div>

            <div class="quick-desc">
                Melihat dan mengelola seluruh user.
            </div>

        </a>


        <a href="tambah_user.php">

            <div class="quick-icon">
                ➕
            </div>

            <div class="quick-title">
                Tambah User
            </div>

            <div class="quick-desc">
                Membuat akun user baru.
            </div>

        </a>

    </div>


</main>

</body>

</html>