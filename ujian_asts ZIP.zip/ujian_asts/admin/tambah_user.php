<?php

session_start();

require_once "../config/koneksi.php";
require_once "../config/fonnte.php";

if (!isset($_SESSION['login'])) {
    header("Location: ../login.php");
    exit;
}

if ($_SESSION['role'] !== 'admin') {
    header("Location: ../dashboard.php");
    exit;
}

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name     = trim($_POST['name'] ?? '');
    $nisn     = trim($_POST['nisn'] ?? '');
    $ttl      = trim($_POST['ttl'] ?? '');
    $gender   = trim($_POST['gender'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $no_hp    = trim($_POST['no_hp'] ?? '');
    $role     = trim($_POST['role'] ?? 'user');
    $address  = trim($_POST['address'] ?? '');
    $password = $_POST['password'] ?? '';

    if (
        $name === '' ||
        $nisn === '' ||
        $ttl === '' ||
        $gender === '' ||
        $email === '' ||
        $address === '' ||
        $password === ''
    ) {

        $error = "Semua data wajib diisi.";

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        $error = "Format email tidak valid.";

    } elseif (!in_array($role, ['admin', 'user'], true)) {

        $error = "Role tidak valid.";

    } elseif (strlen($password) < 6) {

        $error = "Password minimal 6 karakter.";

    } else {

        // Cek email
        $cek = $conn->prepare("
            SELECT id
            FROM users
            WHERE email = ?
            LIMIT 1
        ");

        $cek->bind_param("s", $email);
        $cek->execute();

        $cekResult = $cek->get_result();

        if ($cekResult->num_rows > 0) {

            $error = "Email sudah digunakan.";

        } else {

            // Password hash
            $passwordHash = password_hash(
                $password,
                PASSWORD_DEFAULT
            );

            // Simpan user
            $stmt = $conn->prepare("
                INSERT INTO users
                (
                    name,
                    nisn,
                    ttl,
                    gender,
                    email,
                    no_hp,
                    role,
                    address,
                    password
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");

            $stmt->bind_param(
                "sssssssss",
                $name,
                $nisn,
                $ttl,
                $gender,
                $email,
                $no_hp,
                $role,
                $address,
                $passwordHash
            );

            if ($stmt->execute()) {

                /*
                |--------------------------------------------------------------------------
                | USER BERHASIL DITAMBAHKAN
                |--------------------------------------------------------------------------
                */

                $_SESSION['notif'] =
                    "User berhasil ditambahkan: " . $name;


                /*
                |--------------------------------------------------------------------------
                | KIRIM WHATSAPP
                |--------------------------------------------------------------------------
                */

                if ($no_hp !== '') {

                    $pesan =
                        "🔔 NOTIFIKASI UJIAN ASTS\n\n" .
                        "Halo " . $name . ",\n\n" .
                        "Akun Anda telah berhasil dibuat oleh administrator.\n\n" .
                        "Detail akun:\n" .
                        "Nama: " . $name . "\n" .
                        "Email: " . $email . "\n" .
                        "Role: " . strtoupper($role) . "\n\n" .
                        "Password: " . $password . "\n\n" .
                        "Waktu: " . date('d-m-Y H:i:s') . "\n\n" .
                        "Silakan login ke sistem Ujian ASTS.";

                    $hasilWA = kirimWhatsApp(
                        $no_hp,
                        $pesan
                    );

                    // Untuk pengecekan sementara
                    $_SESSION['wa_tambah_status'] = $hasilWA;
                }


                /*
                |--------------------------------------------------------------------------
                | KEMBALI KE DATA USER
                |--------------------------------------------------------------------------
                */

                header("Location: users.php");
                exit;

            } else {

                $error =
                    "Gagal menambahkan user: " .
                    $conn->error;
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Tambah User - Admin Ujian ASTS</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f1f5f7;
    color: #102530;
}

/* SIDEBAR */

.sidebar {
    position: fixed;
    left: 0;
    top: 0;
    bottom: 0;
    width: 250px;
    background: #0b6e6e;
    color: white;
    padding: 25px 18px;
}

.logo {
    text-align: center;
    font-size: 25px;
    font-weight: bold;
    margin-bottom: 35px;
}

.logo span {
    display: block;
    font-size: 40px;
    margin-bottom: 8px;
}

.logo small {
    display: block;
    font-size: 12px;
    opacity: .8;
    margin-top: 5px;
}

.nav a {
    display: block;
    color: white;
    text-decoration: none;
    padding: 13px 15px;
    border-radius: 9px;
    margin-bottom: 8px;
}

.nav a:hover {
    background: rgba(255,255,255,.15);
}

.nav a.active {
    background: rgba(255,255,255,.20);
    font-weight: bold;
}

.nav .logout {
    position: absolute;
    left: 18px;
    right: 18px;
    bottom: 25px;
    background: #a4262c;
}

/* MAIN */

.main {
    margin-left: 250px;
    padding: 30px;
}

.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 25px;
}

.header h1 {
    margin: 0;
    font-size: 28px;
}

.header p {
    color: #71828a;
    margin: 7px 0 0;
}

.admin-info {
    background: white;
    padding: 12px 18px;
    border-radius: 10px;
    box-shadow: 0 5px 20px rgba(0,0,0,.05);
}

.badge {
    background: #e0f0ee;
    color: #0b6e6e;
    padding: 5px 10px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: bold;
}

/* PANEL */

.panel {
    background: white;
    border-radius: 15px;
    box-shadow: 0 5px 20px rgba(0,0,0,.05);
    overflow: hidden;
}

.panel-header {
    padding: 22px;
    border-bottom: 1px solid #e5ebee;
}

.panel-header h2 {
    margin: 0;
}

.panel-header p {
    color: #71828a;
    font-size: 13px;
}

/* FORM */

.form {
    padding: 25px;
}

.grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
}

.field {
    margin-bottom: 18px;
}

.field.full {
    grid-column: 1 / -1;
}

.field label {
    display: block;
    font-weight: bold;
    font-size: 13px;
    margin-bottom: 7px;
}

.field input,
.field select,
.field textarea {
    width: 100%;
    padding: 12px;
    border: 1px solid #d9e2e6;
    border-radius: 9px;
    font-size: 14px;
    font-family: Arial, sans-serif;
}

.field textarea {
    min-height: 100px;
    resize: vertical;
}

.field input:focus,
.field select:focus,
.field textarea:focus {
    outline: 2px solid #0b6e6e;
    border-color: #0b6e6e;
}

/* ALERT */

.alert {
    margin: 20px 25px 0;
    padding: 12px 15px;
    border-radius: 9px;
    font-size: 14px;
}

.alert-error {
    background: #fbe7e7;
    color: #a4262c;
}

.alert-success {
    background: #e0f0ee;
    color: #0b6e6e;
}

/* BUTTON */

.form-footer {
    display: flex;
    justify-content: flex-end;
    gap: 10px;
    padding-top: 10px;
}

.btn {
    display: inline-block;
    padding: 11px 18px;
    border: 0;
    border-radius: 9px;
    text-decoration: none;
    font-weight: bold;
    cursor: pointer;
    font-size: 14px;
}

.btn-primary {
    background: #0b6e6e;
    color: white;
}

.btn-primary:hover {
    background: #095a5a;
}

.btn-secondary {
    background: #e9eef0;
    color: #52656e;
}

.btn-secondary:hover {
    background: #dce4e7;
}

.footer {
    text-align: center;
    margin-top: 25px;
    color: #71828a;
    font-size: 12px;
}

/* RESPONSIVE */

@media (max-width: 800px) {

    .sidebar {
        position: relative;
        width: 100%;
    }

    .main {
        margin-left: 0;
    }

    .nav .logout {
        position: static;
        margin-top: 15px;
    }

    .grid {
        grid-template-columns: 1fr;
    }

    .field.full {
        grid-column: auto;
    }

    .header {
        display: block;
    }

    .admin-info {
        display: inline-block;
        margin-top: 15px;
    }
}

</style>

</head>

<body>


<!-- SIDEBAR -->

<aside class="sidebar">

    <div class="logo">

        <span>🛡️</span>

        Ujian ASTS

        <small>Admin Panel</small>

    </div>


    <nav class="nav">

        <a href="dashboard.php">
            🏠 Dashboard
        </a>

        <a href="users.php">
            👥 Data User
        </a>

        <a href="tambah_user.php" class="active">
            ➕ Tambah User
        </a>


        <a href="profil.php">
            📋 Profil Saya
        </a>

        <a href="../logout.php" class="logout">
            🚪 Logout
        </a>

    </nav>

</aside>


<!-- MAIN -->

<main class="main">


    <div class="header">

        <div>

            <h1>➕ Tambah User</h1>

            <p>
                Tambahkan akun pengguna baru ke sistem Ujian ASTS.
            </p>

        </div>


        <div class="admin-info">

            👋
            <strong>
                <?= htmlspecialchars($_SESSION['username']) ?>
            </strong>

            <span class="badge">
                ADMIN
            </span>

        </div>

    </div>


    <div class="panel">

        <div class="panel-header">

            <h2>Form Data User</h2>

            <p>
                Isi data pengguna dengan lengkap.
            </p>

        </div>


        <?php if ($error): ?>

            <div class="alert alert-error">
                ❌ <?= htmlspecialchars($error) ?>
            </div>

        <?php endif; ?>


        <form method="POST" class="form">

            <div class="grid">


                <div class="field">

                    <label>Nama Lengkap</label>

                    <input
                        type="text"
                        name="name"
                        value="<?= htmlspecialchars($_POST['name'] ?? '') ?>"
                        required
                    >

                </div>


                <div class="field">

                    <label>NISN</label>

                    <input
                        type="text"
                        name="nisn"
                        value="<?= htmlspecialchars($_POST['nisn'] ?? '') ?>"
                        required
                    >

                </div>


                <div class="field">

                    <label>Tempat, Tanggal Lahir</label>

                    <input
                        type="text"
                        name="ttl"
                        placeholder="Sumenep, 12 Mei 2009"
                        value="<?= htmlspecialchars($_POST['ttl'] ?? '') ?>"
                        required
                    >

                </div>


                <div class="field">

                    <label>Gender</label>

                    <select name="gender" required>

                        <option value="">
                            -- Pilih Gender --
                        </option>

                        <option value="MALE">
                            Laki-laki
                        </option>

                        <option value="FEMALE">
                            Perempuan
                        </option>

                    </select>

                </div>


                <div class="field">

                    <label>Email</label>

                    <input
                        type="email"
                        name="email"
                        value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                        required
                    >

                </div>


                <div class="field">

                    <label>No. HP / WhatsApp</label>

                    <input
                        type="text"
                        name="no_hp"
                        placeholder="628xxxxxxxxxx"
                        value="<?= htmlspecialchars($_POST['no_hp'] ?? '') ?>"
                    >

                </div>


                <div class="field">

                    <label>Role</label>

                    <select name="role">

                        <option value="user">
                            User
                        </option>

                        <option value="admin">
                            Admin
                        </option>

                    </select>

                </div>


                <div class="field">

                    <label>Password</label>

                    <input
                        type="password"
                        name="password"
                        minlength="6"
                        required
                    >

                </div>


                <div class="field full">

                    <label>Alamat</label>

                    <textarea
                        name="address"
                        required
                    ><?= htmlspecialchars($_POST['address'] ?? '') ?></textarea>

                </div>


            </div>


            <div class="form-footer">

                <a
                    href="users.php"
                    class="btn btn-secondary"
                >
                    ← Kembali
                </a>

                <button
                    type="submit"
                    class="btn btn-primary"
                >
                    💾 Simpan User
                </button>

            </div>

        </form>

    </div>


    <div class="footer">

        Ujian ASTS © 2026 — Admin Panel

    </div>

</main>

</body>

</html>