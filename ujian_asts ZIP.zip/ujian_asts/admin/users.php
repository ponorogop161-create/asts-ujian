<?php

session_start();

if (!isset($_SESSION['login'])) {
    header("Location: ../login.php");
    exit;
}

if ($_SESSION['role'] !== 'admin') {
    header("Location: ../dashboard.php");
    exit;
}

require_once "../config/koneksi.php";

$result = $conn->query("
    SELECT
        id,
        name,
        nisn,
        ttl,
        gender,
        email,
        no_hp,
        role,
        address,
        created_at
    FROM users
    ORDER BY id ASC
");

?>

<!DOCTYPE html>
<html lang="id">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Data User - Admin Ujian ASTS</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f1f5f7;
    color: #102530;
}


/* ================= SIDEBAR ================= */

.sidebar {
    position: fixed;
    left: 0;
    top: 0;
    bottom: 0;
    width: 250px;
    background: #0b6e6e;
    color: white;
    padding: 25px 18px;
    z-index: 1000;
}

.logo-admin {
    text-align: center;
    font-size: 25px;
    font-weight: bold;
    margin-bottom: 35px;
}

.logo-admin span {
    display: block;
    font-size: 40px;
    margin-bottom: 8px;
}

.logo-admin small {
    display: block;
    font-size: 12px;
    opacity: .8;
    margin-top: 5px;
}

.nav a {
    display: block;
    color: white;
    text-decoration: none;
    padding: 13px 15px;
    border-radius: 9px;
    margin-bottom: 8px;
    transition: .2s;
}

.nav a:hover {
    background: rgba(255,255,255,.15);
}

.nav a.active {
    background: rgba(255,255,255,.20);
    font-weight: bold;
}

.nav .logout {
    position: absolute;
    left: 18px;
    right: 18px;
    bottom: 25px;
    background: #a4262c;
}

.nav .logout:hover {
    background: #8e2025;
}


/* ================= MAIN ================= */

.main {
    margin-left: 250px;
    padding: 30px;
}


/* ================= HEADER ================= */

.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
}

.header h1 {
    margin: 0;
    font-size: 28px;
}

.header p {
    margin: 6px 0 0;
    color: #71828a;
}

.admin-info {
    background: white;
    padding: 12px 18px;
    border-radius: 10px;
    box-shadow: 0 5px 20px rgba(0,0,0,.05);
}

.badge {
    background: #e0f0ee;
    color: #0b6e6e;
    padding: 5px 10px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: bold;
    margin-left: 5px;
}


/* ================= TOOLBAR ================= */

.toolbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 15px;
    margin-bottom: 20px;
}

.search {
    flex: 1;
}

.search input {
    width: 100%;
    padding: 13px 15px;
    border: 1px solid #d9e2e6;
    border-radius: 9px;
    background: white;
    font-size: 14px;
}

.search input:focus {
    outline: 2px solid #0b6e6e;
    border-color: #0b6e6e;
}

.toolbar-buttons {
    display: flex;
    gap: 8px;
}


/* ================= BUTTON ================= */

.btn {
    display: inline-block;
    padding: 11px 17px;
    background: #0b6e6e;
    color: white;
    text-decoration: none;
    border-radius: 9px;
    font-weight: bold;
    font-size: 14px;
    border: none;
    cursor: pointer;
}

.btn:hover {
    background: #095a5a;
}

.btn-back {
    background: #60737c;
}

.btn-back:hover {
    background: #4d6068;
}


/* ================= PANEL ================= */

.panel {
    background: white;
    border-radius: 15px;
    overflow: hidden;
    box-shadow: 0 5px 20px rgba(0,0,0,.05);
}

.panel-header {
    padding: 20px;
    border-bottom: 1px solid #e5ebee;
}

.panel-header h2 {
    margin: 0;
    font-size: 19px;
}

.panel-header p {
    margin: 5px 0 0;
    color: #71828a;
    font-size: 13px;
}


/* ================= TABLE ================= */

.table-scroll {
    overflow-x: auto;
}

table {
    width: 100%;
    border-collapse: collapse;
    min-width: 1100px;
}

thead th {
    text-align: left;
    padding: 14px 16px;
    background: #f7fafb;
    color: #536b75;
    font-size: 12px;
    white-space: nowrap;
}

tbody td {
    padding: 14px 16px;
    border-top: 1px solid #edf1f3;
    font-size: 13px;
    vertical-align: middle;
}

tbody tr:hover {
    background: #f8fbfb;
}


/* ================= USER ================= */

.user-name {
    font-weight: bold;
}

.user-email {
    color: #71828a;
    font-size: 12px;
    margin-top: 3px;
}

.role-admin {
    display: inline-block;
    background: #e0f0ee;
    color: #0b6e6e;
    padding: 5px 9px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: bold;
}

.role-user {
    display: inline-block;
    background: #eef2f4;
    color: #52656e;
    padding: 5px 9px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: bold;
}


/* ================= ACTION ================= */

.aksi {
    display: flex;
    gap: 6px;
}

.btn-edit {
    background: #f0ad4e;
    color: white;
    padding: 7px 10px;
    border-radius: 7px;
    text-decoration: none;
    font-size: 12px;
    font-weight: bold;
}

.btn-edit:hover {
    background: #d99530;
}

.btn-delete {
    background: #dc3545;
    color: white;
    padding: 7px 10px;
    border-radius: 7px;
    text-decoration: none;
    font-size: 12px;
    font-weight: bold;
}

.btn-delete:hover {
    background: #bd2635;
}


/* ================= FOOTER ================= */

.footer {
    margin-top: 25px;
    text-align: center;
    color: #71828a;
    font-size: 12px;
}

.notif-success {
    background: #e0f0ee;
    color: #0b6e6e;
    padding: 14px 18px;
    border-radius: 10px;
    margin-bottom: 20px;
    font-weight: 600;
    border-left: 5px solid #0b6e6e;
}


/* ================= RESPONSIVE ================= */

@media(max-width: 900px) {

    .sidebar {
        width: 210px;
    }

    .main {
        margin-left: 210px;
    }

    .header {
        display: block;
    }

    .admin-info {
        display: inline-block;
        margin-top: 15px;
    }

}

@media(max-width: 700px) {

    .sidebar {
        position: relative;
        width: 100%;
        min-height: auto;
    }

    .main {
        margin-left: 0;
        padding: 20px;
    }

    .nav .logout {
        position: static;
        margin-top: 15px;
    }

    .toolbar {
        display: block;
    }

    .toolbar-buttons {
        margin-top: 10px;
    }

}

</style>

</head>


<body>


<!-- ================= SIDEBAR ================= -->

<aside class="sidebar">

    <div class="logo-admin">

        <span>🛡️</span>

        Ujian ASTS

        <small>Admin Panel</small>

    </div>


    <nav class="nav">

        <a href="dashboard.php">
            🏠 Dashboard
        </a>

        <a href="users.php" class="active">
            👥 Data User
        </a>

        <a href="tambah_user.php">
            ➕ Tambah User
        </a>

        <a href="profil.php">
            📋 Profil Saya
        </a>

        <a href="../logout.php" class="logout">
            🚪 Logout
        </a>

    </nav>

</aside>



<!-- ================= MAIN ================= -->

<main class="main">

    <?php if (!empty($_SESSION['notif'])): ?>

    <div class="notif-success">
        ✅
        <?= htmlspecialchars($_SESSION['notif']) ?>
    </div>

    <?php unset($_SESSION['notif']); ?>

<?php endif; ?>
    

    <!-- HEADER -->

    <div class="header">

        <div>

            <h1>
                👥 Data User
            </h1>

            <p>
                Kelola seluruh akun pengguna Ujian ASTS.
            </p>

        </div>


        <div class="admin-info">

            👋

            <strong>
                <?= htmlspecialchars($_SESSION['username']) ?>
            </strong>

            <span class="badge">
                ADMIN
            </span>

        </div>

    </div>



    <!-- ================= TOOLBAR ================= -->

    <div class="toolbar">

        <div class="search">

            <input
                type="text"
                id="cariUser"
                placeholder="🔎 Cari nama, email, NISN, atau role..."
            >

        </div>


        <div class="toolbar-buttons">

            <a
                href="dashboard.php"
                class="btn btn-back"
            >
                ← Dashboard
            </a>

            <a
                href="tambah_user.php"
                class="btn"
            >
                + Tambah User
            </a>

        </div>

    </div>



    <!-- ================= PANEL ================= -->

    <div class="panel">


        <div class="panel-header">

            <h2>
                Daftar Seluruh User
            </h2>

            <p>
                Menampilkan semua akun yang terdaftar di sistem.
            </p>

        </div>



        <div class="table-scroll">

            <table id="tabelUser">

                <thead>

                    <tr>

                        <th>ID</th>

                        <th>USER</th>

                        <th>NISN</th>

                        <th>TTL</th>

                        <th>GENDER</th>

                        <th>NO. HP</th>

                        <th>ROLE</th>

                        <th>TANGGAL DAFTAR</th>

                        <th>AKSI</th>

                    </tr>

                </thead>


                <tbody>

                <?php if ($result && $result->num_rows > 0): ?>


                    <?php while ($user = $result->fetch_assoc()): ?>

                    <tr>


                        <td>
                            <?= htmlspecialchars($user['id']) ?>
                        </td>


                        <td>

                            <div class="user-name">

                                <?= htmlspecialchars($user['name']) ?>

                            </div>

                            <div class="user-email">

                                <?= htmlspecialchars($user['email']) ?>

                            </div>

                        </td>


                        <td>

                            <?= htmlspecialchars($user['nisn']) ?>

                        </td>


                        <td>

                            <?= htmlspecialchars($user['ttl']) ?>

                        </td>


                        <td>

                            <?= htmlspecialchars($user['gender']) ?>

                        </td>


                        <td>

                            <?= htmlspecialchars(
                                $user['no_hp'] ?? '-'
                            ) ?>

                        </td>


                        <td>

                            <?php if ($user['role'] === 'admin'): ?>

                                <span class="role-admin">
                                    ADMIN
                                </span>

                            <?php else: ?>

                                <span class="role-user">
                                    USER
                                </span>

                            <?php endif; ?>

                        </td>


                        <td>

                            <?= htmlspecialchars(
                                $user['created_at']
                            ) ?>

                        </td>


                        <td>

                            <div class="aksi">

                                <a
                                    href="edit_user.php?id=<?= (int)$user['id'] ?>"
                                    class="btn-edit"
                                >
                                    ✏️ Edit
                                </a>


                                <a
    href="hapus_user.php?id=<?= $user['id'] ?>"
    class="btn-delete"
    onclick="return confirm('Yakin ingin menghapus akun <?= htmlspecialchars($user['name']) ?>?')"
>
    Hapus
</a>

                            </div>

                        </td>


                    </tr>

                    <?php endwhile; ?>


                <?php else: ?>


                    <tr>

                        <td
                            colspan="9"
                            style="text-align:center;padding:40px;"
                        >

                            👤 Belum ada data user.

                        </td>

                    </tr>


                <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>



    <!-- FOOTER -->

    <div class="footer">

        Ujian ASTS © 2026 — Admin Panel

    </div>


</main>



<!-- ================= SEARCH ================= -->

<script>

const input = document.getElementById("cariUser");

input.addEventListener("input", function () {

    const keyword = this.value.toLowerCase().trim();

    const rows = document.querySelectorAll(
        "#tabelUser tbody tr"
    );

    rows.forEach(function (row) {

        const text = row.innerText.toLowerCase();

        if (text.includes(keyword)) {

            row.style.display = "";

        } else {

            row.style.display = "none";

        }

    });

});

</script>


</body>

</html>