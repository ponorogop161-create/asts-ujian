<?php

session_start();

if (!isset($_SESSION['login'])) {
    header("Location: ../login.php");
    exit;
}

if ($_SESSION['role'] !== 'admin') {
    header("Location: ../dashboard.php");
    exit;
}

require_once "../config/koneksi.php";

$totalUser = 0;
$totalAdmin = 0;
$totalUserBiasa = 0;

$result = $conn->query("SELECT COUNT(*) AS total FROM users");
if ($result) {
    $totalUser = $result->fetch_assoc()['total'];
}

$result = $conn->query("
    SELECT COUNT(*) AS total
    FROM users
    WHERE role = 'admin'
");

if ($result) {
    $totalAdmin = $result->fetch_assoc()['total'];
}

$result = $conn->query("
    SELECT COUNT(*) AS total
    FROM users
    WHERE role = 'user'
");

if ($result) {
    $totalUserBiasa = $result->fetch_assoc()['total'];
}

$usersBaru = [];

$result = $conn->query("
    SELECT id, name, email, role, created_at
    FROM users
    ORDER BY id DESC
    LIMIT 5
");

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $usersBaru[] = $row;
    }
}

?>

<!DOCTYPE html>
<html lang="id">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Admin Dashboard - Ujian ASTS</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f1f5f7;
    color: #102530;
}

/* SIDEBAR */

.sidebar {
    position: fixed;
    left: 0;
    top: 0;
    bottom: 0;
    width: 250px;
    background: #0b6e6e;
    color: white;
    padding: 25px 18px;
}

.logo {
    text-align: center;
    font-size: 25px;
    font-weight: bold;
    margin-bottom: 35px;
}

.logo span {
    display: block;
    font-size: 40px;
    margin-bottom: 8px;
}

.nav a {
    display: block;
    color: white;
    text-decoration: none;
    padding: 13px 15px;
    border-radius: 9px;
    margin-bottom: 8px;
    transition: .2s;
}

.nav a:hover,
.nav a.active {
    background: rgba(255,255,255,.15);
}

.logout {
    position: absolute;
    left: 18px;
    right: 18px;
    bottom: 25px;
    background: #a4262c;
}

/* CONTENT */

.main {
    margin-left: 250px;
    padding: 30px;
}

.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
}

.header h1 {
    margin: 0;
    font-size: 28px;
}

.header p {
    margin: 6px 0 0;
    color: #71828a;
}

.admin-info {
    background: white;
    padding: 12px 18px;
    border-radius: 10px;
    box-shadow: 0 5px 20px rgba(0,0,0,.05);
}

.badge {
    background: #e0f0ee;
    color: #0b6e6e;
    padding: 5px 10px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: bold;
}

/* CARDS */

.cards {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 20px;
    margin-bottom: 30px;
}

.card {
    background: white;
    border-radius: 15px;
    padding: 23px;
    box-shadow: 0 5px 20px rgba(0,0,0,.05);
}

.card-icon {
    font-size: 30px;
}

.card-title {
    color: #71828a;
    margin-top: 12px;
    font-size: 14px;
}

.card-number {
    font-size: 32px;
    font-weight: bold;
    margin-top: 5px;
}

/* PANEL */

.panel {
    background: white;
    border-radius: 15px;
    overflow: hidden;
    box-shadow: 0 5px 20px rgba(0,0,0,.05);
}

.panel-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20px;
    border-bottom: 1px solid #e5ebee;
}

.panel-header h2 {
    margin: 0;
    font-size: 19px;
}

.btn {
    display: inline-block;
    padding: 9px 15px;
    background: #0b6e6e;
    color: white;
    text-decoration: none;
    border-radius: 8px;
    font-weight: bold;
    font-size: 14px;
}

table {
    width: 100%;
    border-collapse: collapse;
}

th {
    text-align: left;
    padding: 14px 20px;
    background: #f8fafb;
    color: #536b75;
    font-size: 13px;
}

td {
    padding: 14px 20px;
    border-top: 1px solid #edf1f3;
}

.role-admin {
    background: #e0f0ee;
    color: #0b6e6e;
    padding: 5px 9px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: bold;
}

.role-user {
    background: #eef2f4;
    color: #52656e;
    padding: 5px 9px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: bold;
}

/* RESPONSIVE */

@media(max-width:850px) {

    .sidebar {
        width: 200px;
    }

    .main {
        margin-left: 200px;
    }

    .cards {
        grid-template-columns: 1fr;
    }
}

@media(max-width:650px) {

    .sidebar {
        position: static;
        width: 100%;
    }

    .main {
        margin-left: 0;
    }

    .logout {
        position: static;
        margin-top: 20px;
    }

    .header {
        display: block;
    }

    .admin-info {
        margin-top: 15px;
    }

}

</style>

</head>

<body>

<aside class="sidebar">

    <div class="logo">
        <span>🛡️</span>
        Ujian ASTS
        <small>Admin Panel</small>
    </div>

    <nav class="nav">

        <a href="dashboard.php" class="active">
            🏠 Dashboard
        </a>

        <a href="users.php">
            👥 Data User
        </a>

        <a href="tambah_user.php">
            ➕ Tambah User
        </a>

        <a href="profil.php">
            📋 Profil Saya
        </a>

        <a href="../logout.php" class="logout">
            🚪 Logout
        </a>

    </nav>

</aside>


<main class="main">

    <div class="header">

        <div>
            <h1>Dashboard Admin</h1>

            <p>
                Selamat datang di panel administrator Ujian ASTS.
            </p>
        </div>

        <div class="admin-info">

            👋
            <strong>
                <?= htmlspecialchars($_SESSION['username']) ?>
            </strong>

            <span class="badge">
                ADMIN
            </span>

        </div>

    </div>


    <!-- STATISTIK -->

    <div class="cards">

        <div class="card">

            <div class="card-icon">
                👥
            </div>

            <div class="card-title">
                Total User
            </div>

            <div class="card-number">
                <?= $totalUser ?>
            </div>

        </div>


        <div class="card">

            <div class="card-icon">
                🛡️
            </div>

            <div class="card-title">
                Administrator
            </div>

            <div class="card-number">
                <?= $totalAdmin ?>
            </div>

        </div>


        <div class="card">

            <div class="card-icon">
                👨‍🎓
            </div>

            <div class="card-title">
                User Biasa
            </div>

            <div class="card-number">
                <?= $totalUserBiasa ?>
            </div>

        </div>

    </div>


    <!-- USER TERBARU -->

    <div class="panel">

        <div class="panel-header">

            <h2>
                🔔 User Terbaru
            </h2>

            <a href="users.php" class="btn">
                Lihat Semua
            </a>

        </div>


        <table>

            <thead>

                <tr>

                    <th>ID</th>

                    <th>Nama</th>

                    <th>Email</th>

                    <th>Role</th>

                    <th>Tanggal Daftar</th>

                </tr>

            </thead>


            <tbody>

            <?php if (empty($usersBaru)): ?>

                <tr>

                    <td colspan="5" style="text-align:center;">
                        Belum ada data user.
                    </td>

                </tr>

            <?php else: ?>

                <?php foreach ($usersBaru as $user): ?>

                    <tr>

                        <td>
                            <?= htmlspecialchars($user['id']) ?>
                        </td>

                        <td>
                            <strong>
                                <?= htmlspecialchars($user['name']) ?>
                            </strong>
                        </td>

                        <td>
                            <?= htmlspecialchars($user['email']) ?>
                        </td>

                        <td>

                            <?php if ($user['role'] === 'admin'): ?>

                                <span class="role-admin">
                                    ADMIN
                                </span>

                            <?php else: ?>

                                <span class="role-user">
                                    USER
                                </span>

                            <?php endif; ?>

                        </td>

                        <td>
                            <?= htmlspecialchars($user['created_at']) ?>
                        </td>

                    </tr>

                <?php endforeach; ?>

            <?php endif; ?>

            </tbody>

        </table>

    </div>

</main>

</body>

</html>