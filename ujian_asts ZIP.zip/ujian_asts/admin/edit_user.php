<?php

session_start();

require_once "../config/koneksi.php";
require_once "../config/fonnte.php";

if (!isset($_SESSION['login'])) {
    header("Location: ../login.php");
    exit;
}

if ($_SESSION['role'] !== 'admin') {
    header("Location: ../dashboard.php");
    exit;
}

$id = intval($_GET['id'] ?? 0);

if ($id <= 0) {
    header("Location: users.php");
    exit;
}

/*
|--------------------------------------------------------------------------
| Ambil data user
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    SELECT
        id,
        name,
        nisn,
        ttl,
        gender,
        email,
        no_hp,
        role,
        address
    FROM users
    WHERE id = ?
    LIMIT 1
");

$stmt->bind_param("i", $id);
$stmt->execute();

$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    header("Location: users.php");
    exit;
}

$error = "";

/*
|--------------------------------------------------------------------------
| Proses update
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name     = trim($_POST['name'] ?? '');
    $nisn     = trim($_POST['nisn'] ?? '');
    $ttl      = trim($_POST['ttl'] ?? '');
    $gender   = trim($_POST['gender'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $no_hp    = trim($_POST['no_hp'] ?? '');
    $role     = trim($_POST['role'] ?? 'user');
    $address  = trim($_POST['address'] ?? '');
    $password = $_POST['password'] ?? '';

    if (
        $name === '' ||
        $nisn === '' ||
        $ttl === '' ||
        $gender === '' ||
        $email === '' ||
        $address === ''
    ) {

        $error = "Data wajib diisi dengan lengkap.";

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        $error = "Format email tidak valid.";

    } elseif (!in_array($role, ['admin', 'user'], true)) {

        $error = "Role tidak valid.";

    } else {

        /*
        |--------------------------------------------------------------------------
        | Cek email milik user lain
        |--------------------------------------------------------------------------
        */

        $cek = $conn->prepare("
            SELECT id
            FROM users
            WHERE email = ?
            AND id != ?
            LIMIT 1
        ");

        $cek->bind_param("si", $email, $id);
        $cek->execute();

        $cekResult = $cek->get_result();

        if ($cekResult->num_rows > 0) {

            $error = "Email tersebut sudah digunakan user lain.";

        } else {

            /*
            |--------------------------------------------------------------------------
            | Jika password kosong
            |--------------------------------------------------------------------------
            */

            if ($password === '') {

                $update = $conn->prepare("
                    UPDATE users
                    SET
                        name = ?,
                        nisn = ?,
                        ttl = ?,
                        gender = ?,
                        email = ?,
                        no_hp = ?,
                        role = ?,
                        address = ?
                    WHERE id = ?
                ");

                $update->bind_param(
                    "ssssssssi",
                    $name,
                    $nisn,
                    $ttl,
                    $gender,
                    $email,
                    $no_hp,
                    $role,
                    $address,
                    $id
                );

            }

            /*
            |--------------------------------------------------------------------------
            | Jika password diubah
            |--------------------------------------------------------------------------
            */

            else {

                if (strlen($password) < 6) {

                    $error = "Password minimal 6 karakter.";

                } else {

                    $passwordHash = password_hash(
                        $password,
                        PASSWORD_DEFAULT
                    );

                    $update = $conn->prepare("
                        UPDATE users
                        SET
                            name = ?,
                            nisn = ?,
                            ttl = ?,
                            gender = ?,
                            email = ?,
                            no_hp = ?,
                            role = ?,
                            address = ?,
                            password = ?
                        WHERE id = ?
                    ");

                    $update->bind_param(
                        "sssssssssi",
                        $name,
                        $nisn,
                        $ttl,
                        $gender,
                        $email,
                        $no_hp,
                        $role,
                        $address,
                        $passwordHash,
                        $id
                    );
                }
            }

            /*
            |--------------------------------------------------------------------------
            | Simpan perubahan
            |--------------------------------------------------------------------------
            */

            if ($error === "") {

                if ($update->execute()) {

    /*
    |--------------------------------------------------------------------------
    | NOTIFIKASI WEBSITE
    |--------------------------------------------------------------------------
    */

    $_SESSION['notif'] =
        "Data user berhasil diubah: " . $name;


    /*
    |--------------------------------------------------------------------------
    | NOTIFIKASI WHATSAPP
    |--------------------------------------------------------------------------
    */

    if (!empty($no_hp)) {

        $pesan =
            "🔔 NOTIFIKASI UJIAN ASTS\n\n" .
            "Halo " . $name . ",\n\n" .
            "Data akun Anda berhasil diubah oleh administrator.\n\n" .
            "Data yang diperbarui:\n" .
            "• Nama: " . $name . "\n" .
            "• NISN: " . $nisn . "\n" .
            "• Email: " . $email . "\n" .
            "• No. HP: " . $no_hp . "\n" .
            "• Role: " . strtoupper($role) . "\n\n" .
            "Waktu perubahan: " . date('d-m-Y H:i:s') . "\n\n" .
            "Jika perubahan ini bukan dilakukan oleh Anda, silakan hubungi administrator.";

        $hasilWA = kirimWhatsApp(
            $no_hp,
            $pesan
        );


        /*
        |--------------------------------------------------------------------------
        | SIMPAN STATUS WA UNTUK DEBUGGING
        |--------------------------------------------------------------------------
        */

        $_SESSION['wa_edit_status'] = $hasilWA;
    }


    header("Location: users.php");
    exit;

} else {

    $error =
        "Gagal mengubah data: " .
        $conn->error;
}
            }
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Tampilkan kembali data yang diinput jika error
    |--------------------------------------------------------------------------
    */

    $user['name'] = $name;
    $user['nisn'] = $nisn;
    $user['ttl'] = $ttl;
    $user['gender'] = $gender;
    $user['email'] = $email;
    $user['no_hp'] = $no_hp;
    $user['role'] = $role;
    $user['address'] = $address;
}

?>

<!DOCTYPE html>

<html lang="id">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>Edit User - Admin Ujian ASTS</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f1f5f7;
    color: #102530;
}


/* ================= SIDEBAR ================= */

.sidebar {
    position: fixed;
    left: 0;
    top: 0;
    bottom: 0;
    width: 250px;
    background: #0b6e6e;
    color: white;
    padding: 25px 18px;
}

.logo {
    text-align: center;
    font-size: 25px;
    font-weight: bold;
    margin-bottom: 35px;
}

.logo span {
    display: block;
    font-size: 40px;
    margin-bottom: 8px;
}

.logo small {
    display: block;
    font-size: 12px;
    opacity: .8;
    margin-top: 5px;
}

.nav a {
    display: block;
    color: white;
    text-decoration: none;
    padding: 13px 15px;
    border-radius: 9px;
    margin-bottom: 8px;
}

.nav a:hover {
    background: rgba(255,255,255,.15);
}

.nav a.active {
    background: rgba(255,255,255,.20);
    font-weight: bold;
}

.nav .logout {
    position: absolute;
    left: 18px;
    right: 18px;
    bottom: 25px;
    background: #a4262c;
}

.nav .logout:hover {
    background: #8e2025;
}


/* ================= MAIN ================= */

.main {
    margin-left: 250px;
    padding: 30px;
}


/* ================= HEADER ================= */

.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 25px;
}

.header h1 {
    margin: 0;
    font-size: 28px;
}

.header p {
    margin: 7px 0 0;
    color: #71828a;
}

.admin-info {
    background: white;
    padding: 12px 18px;
    border-radius: 10px;
    box-shadow: 0 5px 20px rgba(0,0,0,.05);
}

.badge {
    display: inline-block;
    background: #e0f0ee;
    color: #0b6e6e;
    padding: 5px 10px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: bold;
    margin-left: 5px;
}


/* ================= PANEL ================= */

.panel {
    background: white;
    border-radius: 15px;
    overflow: hidden;
    box-shadow: 0 5px 20px rgba(0,0,0,.05);
}

.panel-header {
    padding: 22px;
    border-bottom: 1px solid #e5ebee;
}

.panel-header h2 {
    margin: 0;
    font-size: 20px;
}

.panel-header p {
    margin: 6px 0 0;
    color: #71828a;
    font-size: 13px;
}


/* ================= ALERT ================= */

.alert {
    margin: 20px 25px 0;
    padding: 13px 15px;
    border-radius: 9px;
    font-size: 14px;
}

.alert-error {
    background: #fbe7e7;
    color: #a4262c;
}


/* ================= FORM ================= */

.form {
    padding: 25px;
}

.grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
}

.field {
    margin-bottom: 18px;
}

.field.full {
    grid-column: 1 / -1;
}

.field label {
    display: block;
    font-size: 13px;
    font-weight: bold;
    margin-bottom: 7px;
}

.field input,
.field select,
.field textarea {
    width: 100%;
    padding: 12px;
    border: 1px solid #d9e2e6;
    border-radius: 9px;
    font-size: 14px;
    font-family: Arial, sans-serif;
}

.field textarea {
    min-height: 100px;
    resize: vertical;
}

.field input:focus,
.field select:focus,
.field textarea:focus {
    outline: 2px solid #0b6e6e;
    border-color: #0b6e6e;
}


/* ================= PASSWORD INFO ================= */

.password-info {
    background: #f7fafb;
    border: 1px solid #e1e8eb;
    padding: 12px;
    border-radius: 9px;
    margin-bottom: 18px;
    font-size: 12px;
    color: #60737c;
}


/* ================= FOOTER FORM ================= */

.form-footer {
    display: flex;
    justify-content: flex-end;
    gap: 10px;
    padding-top: 10px;
}

.btn {
    display: inline-block;
    padding: 11px 18px;
    border: 0;
    border-radius: 9px;
    text-decoration: none;
    font-weight: bold;
    cursor: pointer;
    font-size: 14px;
}

.btn-primary {
    background: #0b6e6e;
    color: white;
}

.btn-primary:hover {
    background: #095a5a;
}

.btn-secondary {
    background: #e9eef0;
    color: #52656e;
}

.btn-secondary:hover {
    background: #dce4e7;
}


/* ================= FOOTER ================= */

.footer {
    text-align: center;
    margin-top: 25px;
    color: #71828a;
    font-size: 12px;
}


/* ================= RESPONSIVE ================= */

@media (max-width: 800px) {

    .sidebar {
        position: relative;
        width: 100%;
    }

    .main {
        margin-left: 0;
    }

    .nav .logout {
        position: static;
        margin-top: 15px;
    }

    .grid {
        grid-template-columns: 1fr;
    }

    .field.full {
        grid-column: auto;
    }

    .header {
        display: block;
    }

    .admin-info {
        display: inline-block;
        margin-top: 15px;
    }

}

</style>

</head>

<body>


<!-- ================= SIDEBAR ================= -->

<aside class="sidebar">

    <div class="logo">

        <span>🛡️</span>

        Ujian ASTS

        <small>Admin Panel</small>

    </div>


    <nav class="nav">

        <a href="dashboard.php">
            🏠 Dashboard
        </a>

        <a href="users.php" class="active">
            👥 Data User
        </a>

        <a href="tambah_user.php">
            ➕ Tambah User
        </a>

        <a href="../dashboard.php">
            👤 Dashboard User
        </a>

        <a href="profil.php">
            📋 Profil Saya
        </a>

        <a href="../logout.php" class="logout">
            🚪 Logout
        </a>

    </nav>

</aside>


<!-- ================= MAIN ================= -->

<main class="main">


    <div class="header">

        <div>

            <h1>✏️ Edit User</h1>

            <p>
                Perbarui informasi akun pengguna.
            </p>

        </div>


        <div class="admin-info">

            👋

            <strong>
                <?= htmlspecialchars($_SESSION['username']) ?>
            </strong>

            <span class="badge">
                ADMIN
            </span>

        </div>

    </div>


    <div class="panel">

        <div class="panel-header">

            <h2>
                Data User #<?= htmlspecialchars($user['id']) ?>
            </h2>

            <p>
                Ubah data yang diperlukan kemudian klik Simpan Perubahan.
            </p>

        </div>


        <?php if ($error): ?>

            <div class="alert alert-error">

                ❌
                <?= htmlspecialchars($error) ?>

            </div>

        <?php endif; ?>


        <form method="POST" class="form">

            <div class="grid">


                <div class="field">

                    <label>
                        Nama Lengkap
                    </label>

                    <input
                        type="text"
                        name="name"
                        value="<?= htmlspecialchars($user['name']) ?>"
                        required
                    >

                </div>


                <div class="field">

                    <label>
                        NISN
                    </label>

                    <input
                        type="text"
                        name="nisn"
                        value="<?= htmlspecialchars($user['nisn']) ?>"
                        required
                    >

                </div>


                <div class="field">

                    <label>
                        Tempat, Tanggal Lahir
                    </label>

                    <input
                        type="text"
                        name="ttl"
                        value="<?= htmlspecialchars($user['ttl']) ?>"
                        required
                    >

                </div>


                <div class="field">

                    <label>
                        Gender
                    </label>

                    <select name="gender" required>

                        <option
                            value="MALE"
                            <?= strtoupper($user['gender']) === 'MALE'
                                ? 'selected'
                                : '' ?>
                        >
                            Laki-laki
                        </option>

                        <option
                            value="FEMALE"
                            <?= strtoupper($user['gender']) === 'FEMALE'
                                ? 'selected'
                                : '' ?>
                        >
                            Perempuan
                        </option>

                    </select>

                </div>


                <div class="field">

                    <label>
                        Email
                    </label>

                    <input
                        type="email"
                        name="email"
                        value="<?= htmlspecialchars($user['email']) ?>"
                        required
                    >

                </div>


                <div class="field">

                    <label>
                        No. HP / WhatsApp
                    </label>

                    <input
                        type="text"
                        name="no_hp"
                        value="<?= htmlspecialchars($user['no_hp'] ?? '') ?>"
                        placeholder="628xxxxxxxxxx"
                    >

                </div>


                <div class="field">

                    <label>
                        Role
                    </label>

                    <select name="role" required>

                        <option
                            value="user"
                            <?= $user['role'] === 'user'
                                ? 'selected'
                                : '' ?>
                        >
                            User
                        </option>

                        <option
                            value="admin"
                            <?= $user['role'] === 'admin'
                                ? 'selected'
                                : '' ?>
                        >
                            Admin
                        </option>

                    </select>

                </div>


                <div class="field">

                    <label>
                        Password Baru
                    </label>

                    <input
                        type="password"
                        name="password"
                        minlength="6"
                        placeholder="Kosongkan jika tidak ingin mengubah"
                    >

                </div>


                <div class="field full">

                    <div class="password-info">

                        🔐
                        Kosongkan Password Baru jika password
                        user tidak ingin diubah.

                    </div>

                </div>


                <div class="field full">

                    <label>
                        Alamat
                    </label>

                    <textarea
                        name="address"
                        required
                    ><?= htmlspecialchars($user['address']) ?></textarea>

                </div>


            </div>


            <div class="form-footer">

                <a
                    href="users.php"
                    class="btn btn-secondary"
                >
                    ← Kembali
                </a>

                <button
                    type="submit"
                    class="btn btn-primary"
                >
                    💾 Simpan Perubahan
                </button>

            </div>

        </form>

    </div>


    <div class="footer">

        Ujian ASTS © 2026 — Admin Panel

    </div>


</main>

</body>

</html>