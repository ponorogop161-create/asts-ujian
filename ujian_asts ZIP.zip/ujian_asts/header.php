<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

$notif = $_SESSION['notif'] ?? null;
unset($_SESSION['notif']);
?>

<?php if ($notif): ?>

<div class="notifikasi">
    ✓ <?= htmlspecialchars($notif) ?>
</div>

<?php endif; ?>


<!DOCTYPE html>

<html lang="id">

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title><?= htmlspecialchars($pageTitle ?? 'Ujian ASTS') ?></title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, Helvetica, sans-serif;
    background: #f1f5f7;
    color: #102530;
}


/* NAVBAR */

.navbar {
    min-height: 70px;
    background: #ffffff;
    border-bottom: 1px solid #dde6ea;

    display: flex;
    align-items: center;
    justify-content: space-between;

    padding: 0 35px;

    position: sticky;
    top: 0;
    z-index: 100;
}

.brand {
    text-decoration: none;
    color: #0b6e6e;
    font-size: 21px;
    font-weight: bold;
    white-space: nowrap;
}

.nav-menu {
    display: flex;
    align-items: center;
    gap: 5px;
}

.nav-menu a {
    text-decoration: none;
    color: #425563;
    padding: 10px 13px;
    border-radius: 8px;
    font-size: 14px;
}

.nav-menu a:hover,
.nav-menu a.active {
    background: #e0f0ee;
    color: #0b6e6e;
}

.nav-menu .logout {
    color: #a4262c;
    background: #fbe7e7;
}

.nav-menu .logout:hover {
    background: #f5d6d6;
    color: #8d1f25;
}


/* USER */

.user-area {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-left: 10px;
    padding-left: 10px;
    border-left: 1px solid #e0e7ea;
}

.user-name {
    font-size: 13px;
    color: #526771;
    white-space: nowrap;
}

.user-avatar {
    width: 34px;
    height: 34px;
    border-radius: 50%;
    background: #e0f0ee;
    color: #0b6e6e;

    display: flex;
    align-items: center;
    justify-content: center;

    font-weight: bold;
}


/* CONTAINER */

.container {
    max-width: 1250px;
    margin: auto;
    padding: 35px 25px 60px;
}


/* FOOTER */

.footer {
    margin-top: 40px;
    padding: 25px;

    text-align: center;

    color: #84949b;
    font-size: 12px;

    border-top: 1px solid #dde6ea;
    background: #ffffff;
}


/* RESPONSIVE */

@media (max-width: 950px) {

    .navbar {
        padding: 15px 20px;
        flex-wrap: wrap;
        gap: 12px;
    }

    .nav-menu {
        width: 100%;
        overflow-x: auto;
        padding-bottom: 3px;
    }

    .user-area {
        display: none;
    }

}


@media (max-width: 600px) {

    .navbar {
        align-items: flex-start;
    }

    .brand {
        font-size: 19px;
    }

    .nav-menu {
        gap: 3px;
    }

    .nav-menu a {
        padding: 8px 10px;
        font-size: 13px;
        white-space: nowrap;
    }

    .container {
        padding: 25px 15px 45px;
    }

}

.notifikasi {
    max-width: 1250px;
    margin: 20px auto 0;
    padding: 14px 18px;

    background: #e0f0ee;
    color: #075d5d;

    border: 1px solid #b9ded9;
    border-radius: 10px;

    font-size: 14px;
    font-weight: 600;

    box-shadow: 0 4px 12px rgba(0,0,0,.04);

    animation: muncul .3s ease;
}

@keyframes muncul {
    from {
        opacity: 0;
        transform: translateY(-8px);
    }

    to {
        opacity: 1;
        transform: translateY(0);
    }
}

</style>

</head>

<body>

<nav class="navbar">

<a href="dashboard.php" class="brand">
🎓 Ujian ASTS
</a>

<div class="nav-menu">

<a href="dashboard.php"
class="<?= ($activePage ?? '') === 'dashboard' ? 'active' : '' ?>">
Dashboard </a>

<a href="index.php"
class="<?= ($activePage ?? '') === 'siswa' ? 'active' : '' ?>">
👨‍🎓 Data Siswa </a>

<a href="profil.php"
class="<?= ($activePage ?? '') === 'profil' ? 'active' : '' ?>">
👤 Profil </a>

<a href="edit_profil.php"
class="<?= ($activePage ?? '') === 'edit_profil' ? 'active' : '' ?>">
✏️ Edit Profil </a>

<div class="user-area">

<div class="user-avatar">
<?= strtoupper(substr($_SESSION['username'] ?? 'U', 0, 1)) ?>
</div>

<div class="user-name">
<?= htmlspecialchars($_SESSION['username'] ?? 'User') ?>
</div>

</div>

<a href="logout.php" class="logout">
Logout
</a>

</div>

</nav>

<script>
setTimeout(function () {
    const notif = document.querySelector(".notifikasi");

    if (notif) {
        notif.style.opacity = "0";
        notif.style.transform = "translateY(-8px)";

        setTimeout(function () {
            notif.remove();
        }, 300);
    }
}, 3500);
</script>