<?php

session_start();

include 'koneksi.php';

$username = $_POST['username'];
$password = md5($_POST['password']);

$query = mysqli_query(
    $koneksi,
    "SELECT * FROM admin
     WHERE username='$username'
     AND password='$password'"
);

$data = mysqli_fetch_assoc($query);

if ($data) {

    $_SESSION['login'] = true;
    $_SESSION['username'] = $data['username'];

    header("Location: index.php");
    exit;

} else {

    header("Location: login.php?error=1");
    exit;

}

?>