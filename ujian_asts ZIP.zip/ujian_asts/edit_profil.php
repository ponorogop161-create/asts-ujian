<?php

session_start();

if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

require_once "config/koneksi.php";
require_once "config/fonnte.php";

$id = $_SESSION['id'];


/*
|--------------------------------------------------------------------------
| PROSES UPDATE
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name    = trim($_POST['name'] ?? '');
    $nisn    = trim($_POST['nisn'] ?? '');
    $ttl     = trim($_POST['ttl'] ?? '');
    $gender  = trim($_POST['gender'] ?? '');
    $email   = trim($_POST['email'] ?? '');
    $no_hp   = trim($_POST['no_hp'] ?? '');
    $address = trim($_POST['address'] ?? '');

    if (
        $name === '' ||
        $nisn === '' ||
        $ttl === '' ||
        $gender === '' ||
        $email === '' ||
        $address === ''
    ) {

        $_SESSION['notif'] = "Data wajib diisi dengan lengkap.";

    } else {

        $stmt = $conn->prepare("
            UPDATE users
            SET
                name = ?,
                nisn = ?,
                ttl = ?,
                gender = ?,
                email = ?,
                no_hp = ?,
                address = ?
            WHERE id = ?
        ");

        $stmt->bind_param(
            "sssssssi",
            $name,
            $nisn,
            $ttl,
            $gender,
            $email,
            $no_hp,
            $address,
            $id
        );

        if ($stmt->execute()) {

    $_SESSION['username'] = $name;

    $_SESSION['notif'] =
        "Data Anda berhasil diubah.";

    /*
    |--------------------------------------------------------------------------
    | Kirim WhatsApp
    |--------------------------------------------------------------------------
    */

    if (!empty($no_hp)) {

        $pesan =
            "🔔 NOTIFIKASI UJIAN ASTS\n\n" .
            "Halo " . $name . ",\n\n" .
            "Data akun Anda berhasil diubah.\n\n" .
            "Perubahan tersimpan pada:\n" .
            "• Nama: " . $name . "\n" .
            "• NISN: " . $nisn . "\n" .
            "• Email: " . $email . "\n" .
            "• No. HP: " . $no_hp . "\n\n" .
            "Jika perubahan ini bukan dilakukan oleh Anda, segera hubungi administrator.";

        $hasilWA = kirimWhatsApp(
            $no_hp,
            $pesan
        );
    }

    header("Location: profil.php");
    exit;
}

            $_SESSION['notif'] =
                "Data gagal diubah.";
        }
    }



/*
|--------------------------------------------------------------------------
| HEADER HARUS SETELAH PROSES PHP
|--------------------------------------------------------------------------
*/

$pageTitle = "Edit Profil - Ujian ASTS";
$activePage = "edit_profil";

include "header.php";

?>

<div class="container">

```
<div style="
    background:#ffffff;
    border:1px solid #dde6ea;
    border-radius:16px;
    padding:28px;
    max-width:800px;
    margin:auto;
">

    <h1 style="margin-top:0;">
        ✏️ Edit Profil
    </h1>

    <p style="color:#71828a;">
        Perbarui informasi pribadi Anda.
    </p>


    <?php

    $stmt = $conn->prepare("
        SELECT
            name,
            nisn,
            ttl,
            gender,
            email,
            no_hp,
            address
        FROM users
        WHERE id = ?
        LIMIT 1
    ");

    $stmt->bind_param("i", $id);
    $stmt->execute();

    $user = $stmt->get_result()->fetch_assoc();

    ?>


    <form method="POST">


        <div style="margin-bottom:18px;">

            <label>
                Nama Lengkap
            </label>

            <input
                type="text"
                name="name"
                value="<?= htmlspecialchars($user['name']) ?>"
                required
                style="
                    width:100%;
                    padding:11px;
                    margin-top:6px;
                    border:1px solid #dde6ea;
                    border-radius:9px;
                "
            >

        </div>


        <div style="margin-bottom:18px;">

            <label>
                NISN
            </label>

            <input
                type="text"
                name="nisn"
                value="<?= htmlspecialchars($user['nisn']) ?>"
                required
                style="
                    width:100%;
                    padding:11px;
                    margin-top:6px;
                    border:1px solid #dde6ea;
                    border-radius:9px;
                "
            >

        </div>


        <div style="margin-bottom:18px;">

            <label>
                Tempat, Tanggal Lahir
            </label>

            <input
                type="text"
                name="ttl"
                value="<?= htmlspecialchars($user['ttl']) ?>"
                required
                style="
                    width:100%;
                    padding:11px;
                    margin-top:6px;
                    border:1px solid #dde6ea;
                    border-radius:9px;
                "
            >

        </div>


        <div style="margin-bottom:18px;">

            <label>
                Gender
            </label>

            <select
                name="gender"
                required
                style="
                    width:100%;
                    padding:11px;
                    margin-top:6px;
                    border:1px solid #dde6ea;
                    border-radius:9px;
                "
            >

                <option
                    value="MALE"
                    <?= strtoupper($user['gender']) === 'MALE' ? 'selected' : '' ?>
                >
                    Laki-laki
                </option>

                <option
                    value="FEMALE"
                    <?= strtoupper($user['gender']) === 'FEMALE' ? 'selected' : '' ?>
                >
                    Perempuan
                </option>

            </select>

        </div>


        <div style="margin-bottom:18px;">

            <label>
                Email
            </label>

            <input
                type="email"
                name="email"
                value="<?= htmlspecialchars($user['email']) ?>"
                required
                style="
                    width:100%;
                    padding:11px;
                    margin-top:6px;
                    border:1px solid #dde6ea;
                    border-radius:9px;
                "
            >

        </div>


        <div style="margin-bottom:18px;">

            <label>
                No. HP
            </label>

            <input
                type="text"
                name="no_hp"
                value="<?= htmlspecialchars($user['no_hp'] ?? '') ?>"
                placeholder="08xxxxxxxxxx"
                style="
                    width:100%;
                    padding:11px;
                    margin-top:6px;
                    border:1px solid #dde6ea;
                    border-radius:9px;
                "
            >

        </div>


        <div style="margin-bottom:22px;">

            <label>
                Alamat
            </label>

            <textarea
                name="address"
                required
                rows="4"
                style="
                    width:100%;
                    padding:11px;
                    margin-top:6px;
                    border:1px solid #dde6ea;
                    border-radius:9px;
                    resize:vertical;
                "
            ><?= htmlspecialchars($user['address']) ?></textarea>

        </div>


        <div style="
            display:flex;
            gap:10px;
            justify-content:flex-end;
        ">

            <a
                href="profil.php"
                style="
                    padding:11px 18px;
                    background:#eef2f4;
                    color:#425563;
                    text-decoration:none;
                    border-radius:9px;
                    font-weight:600;
                "
            >
                Batal
            </a>


            <button
                type="submit"
                style="
                    padding:11px 20px;
                    background:#0b6e6e;
                    color:white;
                    border:0;
                    border-radius:9px;
                    font-weight:600;
                    cursor:pointer;
                "
            >
                Simpan Perubahan
            </button>

        </div>

    </form>

</div>
```

</div>

<?php include "footer.php"; ?>
