<?php

session_start();

if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}


$pageTitle = "Data Siswa - Ujian ASTS";
$activePage = "siswa";

require_once "config/koneksi.php";

include "header.php";



require_once "config/koneksi.php";

$result = $conn->query("
    SELECT id, name, nisn, ttl, gender, email, no_hp, address
    FROM users
    ORDER BY id ASC
");

?>

<!DOCTYPE html>
<html lang="id">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Data Siswa - Ujian ASTS</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f1f5f7;
    color: #102530;
}

.navbar {
    height: 70px;
    background: white;
    border-bottom: 1px solid #ddd;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 35px;
}

.brand {
    color: #0b6e6e;
    text-decoration: none;
    font-size: 21px;
    font-weight: bold;
}

.nav-menu {
    display: flex;
    gap: 8px;
    align-items: center;
}

.nav-menu a {
    text-decoration: none;
    color: #425563;
    padding: 10px 14px;
    border-radius: 8px;
}

.nav-menu a:hover,
.nav-menu a.active {
    background: #e0f0ee;
    color: #0b6e6e;
}

.logout {
    color: #a4262c !important;
    background: #fbe7e7;
}

.container {
    max-width: 1200px;
    margin: auto;
    padding: 35px 25px;
}

.header {
    margin-bottom: 25px;
}

.header h1 {
    margin: 0 0 8px;
}

.header p {
    color: #687b84;
}

.panel {
    background: white;
    border-radius: 16px;
    border: 1px solid #e0e7ea;
    overflow: hidden;
}

.table-wrap {
    overflow-x: auto;
}

table {
    width: 100%;
    border-collapse: collapse;
}

th {
    background: #f7fafb;
    padding: 14px;
    text-align: left;
    font-size: 13px;
    border-bottom: 1px solid #ddd;
}

td {
    padding: 14px;
    border-bottom: 1px solid #eee;
    font-size: 14px;
}

tr:hover {
    background: #f9fcfc;
}

.badge {
    padding: 5px 10px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: bold;
}

.laki {
    background: #e6effa;
    color: #1c4f8f;
}

.perempuan {
    background: #fae9f1;
    color: #95326b;
}

.btn {
    display: inline-block;
    padding: 8px 12px;
    border-radius: 7px;
    text-decoration: none;
    font-size: 13px;
}

.edit {
    background: #fff3d6;
    color: #8a5a00;
}

.hapus {
    background: #fbe7e7;
    color: #a4262c;
}

@media(max-width:800px) {

    .navbar {
        height: auto;
        padding: 15px;
        flex-direction: column;
        gap: 12px;
    }

    .nav-menu {
        flex-wrap: wrap;
        justify-content: center;
    }

}

</style>

</head>

<body>


<main class="container">

<div class="header">

<h1>👨‍🎓 Data Siswa</h1>

<p>
Daftar seluruh data siswa yang terdaftar dalam sistem.
</p>

</div>

<div class="panel">

<div class="table-wrap">

<table>

<thead>

<tr>

<th>ID</th>
<th>Nama</th>
<th>NISN</th>
<th>TTL</th>
<th>Gender</th>
<th>Email</th>
<th>No. HP</th>
<th>Alamat</th>

</tr>

</thead>

<tbody>

<?php if ($result && $result->num_rows > 0): ?>

<?php while ($row = $result->fetch_assoc()): ?>

<tr>

<td>
<?= htmlspecialchars($row['id']) ?>
</td>

<td>
<strong>
<?= htmlspecialchars($row['name']) ?>
</strong>
</td>

<td>
<?= htmlspecialchars($row['nisn']) ?>
</td>

<td>
<?= htmlspecialchars($row['ttl']) ?>
</td>

<td>

<?php if (strtoupper($row['gender']) === 'MALE'): ?>

<span class="badge laki">
Laki-laki
</span>

<?php else: ?>

<span class="badge perempuan">
Perempuan
</span>

<?php endif; ?>

</td>

<td>
<?= htmlspecialchars($row['email']) ?>
</td>

<td>
<?= htmlspecialchars($row['no_hp'] ?? '-') ?>
</td>

<td>
<?= htmlspecialchars($row['address']) ?>
</td>

</tr>

<?php endwhile; ?>

<?php else: ?>

<tr>

<td colspan="8" style="text-align:center;padding:40px">

Belum ada data siswa.

</td>

</tr>

<?php endif; ?>

</tbody>

</table>

</div>

</div>

</main>

</body>

</html>
<?php include "footer.php"; ?>