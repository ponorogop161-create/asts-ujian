<footer class="footer">

<div>
🎓 Ujian ASTS
</div>

<div style="margin-top: 6px;">
Sistem Informasi Data Siswa
</div>

<div style="margin-top: 6px;">
© 2026 Ujian ASTS. Semua hak dilindungi.
</div>

</footer>

</body>

</html>
