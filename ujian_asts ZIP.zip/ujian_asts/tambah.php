<?php

include 'koneksi.php';

$name = $_POST['name'];
$nisn = $_POST['nisn'];
$ttl = $_POST['ttl'];
$gender = $_POST['gender'];
$email = $_POST['email'];
$address = $_POST['address'];

$query = "INSERT INTO users 
          (name, nisn, ttl, gender, email, address)
          VALUES 
          ('$name', '$nisn', '$ttl', '$gender', '$email', '$address')";

if (mysqli_query($koneksi, $query)) {
    echo json_encode([
        "status" => true,
        "message" => "Data berhasil ditambahkan"
    ]);
} else {
    echo json_encode([
        "status" => false,
        "message" => "Data gagal ditambahkan"
    ]);
}
?>