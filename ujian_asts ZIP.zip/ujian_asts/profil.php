<?php

session_start();

if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

require_once "config/koneksi.php";


$pageTitle = "Profil Saya - Ujian ASTS";
$activePage = "profil";

require_once "config/koneksi.php";

include "header.php";

$id = $_SESSION['id'];

$stmt = $conn->prepare(
    "SELECT *
     FROM users
     WHERE id = ?
     LIMIT 1"
);

$stmt->bind_param("i", $id);
$stmt->execute();

$user = $stmt->get_result()->fetch_assoc();

?>

<!DOCTYPE html>
<html lang="id">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Profil Saya</title>

<style>

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f1f5f7;
}

.navbar {
    background: white;
    height: 70px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 35px;
    border-bottom: 1px solid #ddd;
}

.brand {
    color: #0b6e6e;
    font-weight: bold;
    font-size: 21px;
    text-decoration: none;
}

.navbar a {
    text-decoration: none;
    color: #425563;
    margin-left: 18px;
}

.container {
    max-width: 800px;
    margin: 40px auto;
    padding: 0 20px;
}

.profile {
    background: white;
    border-radius: 18px;
    padding: 30px;
    box-shadow: 0 5px 20px rgba(0,0,0,.05);
}

.avatar {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    background: #e0f0ee;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 38px;
    margin-bottom: 20px;
}

.row {
    display: grid;
    grid-template-columns: 180px 1fr;
    padding: 14px 0;
    border-bottom: 1px solid #eee;
}

.label {
    color: #687b84;
    font-weight: bold;
}

.button {
    display: inline-block;
    margin-top: 25px;
    padding: 12px 18px;
    background: #0b6e6e;
    color: white;
    text-decoration: none;
    border-radius: 9px;
}

</style>

</head>

<body>


<div class="container">

<div class="profile">

<div class="avatar">
👤
</div>

<h1>
<?= htmlspecialchars($user['name']) ?>
</h1>

<div class="row">
<div class="label">Nama</div>
<div><?= htmlspecialchars($user['name']) ?></div>
</div>

<div class="row">
<div class="label">NISN</div>
<div><?= htmlspecialchars($user['nisn']) ?></div>
</div>

<div class="row">
<div class="label">TTL</div>
<div><?= htmlspecialchars($user['ttl']) ?></div>
</div>

<div class="row">
<div class="label">Gender</div>
<div><?= htmlspecialchars($user['gender']) ?></div>
</div>

<div class="row">
<div class="label">Email</div>
<div><?= htmlspecialchars($user['email']) ?></div>
</div>

<div class="row">
<div class="label">No. HP</div>
<div><?= htmlspecialchars($user['no_hp'] ?: '-') ?></div>
</div>

<div class="row">
<div class="label">Alamat</div>
<div><?= htmlspecialchars($user['address']) ?></div>
</div>

<a href="edit_profil.php" class="button">
✏️ Edit Profil
</a>

<div style="
    margin-top:30px;
    padding:20px;
    background:#fff5f5;
    border:1px solid #f0cccc;
    border-radius:12px;
">

<h3 style="
    margin-top:0;
    color:#a4262c;
">
    Zona Berbahaya
</h3>

<p style="
    color:#71828a;
    margin-bottom:15px;
">
    Menghapus akun akan menghapus data akun Anda secara permanen.
</p>

<button
    type="button"
    onclick="konfirmasiHapusAkun()"
    style="
        background:#a4262c;
        color:white;
        border:0;
        padding:11px 18px;
        border-radius:9px;
        font-weight:600;
        cursor:pointer;
    "
>
    🗑️ Hapus Akun
</button>

</div>

<script>

function konfirmasiHapusAkun()
{
    const yakin = confirm(
        "Apakah Anda yakin ingin menghapus akun?\n\n" +
        "Data akun akan dihapus secara permanen dan tidak dapat dikembalikan."
    );

    if (yakin) {

        window.location.href = "hapus.php";

    }
}

</script>


</div>

</div>

</body>
</html>
<?php include "footer.php"; ?>