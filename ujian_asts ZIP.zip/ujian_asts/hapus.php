<?php

session_start();

require_once "config/koneksi.php";
require_once "config/fonnte.php";


/*
|--------------------------------------------------------------------------
| Cek login
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION['login']) || !isset($_SESSION['id'])) {

    header("Location: login.php");
    exit;

}


$id = (int) $_SESSION['id'];


/*
|--------------------------------------------------------------------------
| Ambil data user SEBELUM dihapus
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    SELECT
        id,
        name,
        email,
        no_hp
    FROM users
    WHERE id = ?
    LIMIT 1
");

$stmt->bind_param("i", $id);
$stmt->execute();

$result = $stmt->get_result();

$user = $result->fetch_assoc();


if (!$user) {

    session_unset();
    session_destroy();

    header("Location: login.php");
    exit;

}


/*
|--------------------------------------------------------------------------
| Kirim notifikasi WhatsApp
|--------------------------------------------------------------------------
*/

if (!empty($user['no_hp'])) {

    $pesan =
        "🔔 NOTIFIKASI UJIAN ASTS\n\n" .
        "Halo " . $user['name'] . ",\n\n" .
        "Akun Anda telah dihapus dari sistem Ujian ASTS.\n\n" .
        "Email: " . $user['email'] . "\n" .
        "Waktu: " . date('d-m-Y H:i:s') . "\n\n" .
        "Jika penghapusan ini bukan dilakukan oleh Anda, silakan hubungi administrator.";

    kirimWhatsApp(
        $user['no_hp'],
        $pesan
    );

}


/*
|--------------------------------------------------------------------------
| Hapus akun dari database
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    DELETE FROM users
    WHERE id = ?
");

$stmt->bind_param("i", $id);


if ($stmt->execute()) {

    /*
    |--------------------------------------------------------------------------
    | Hapus session
    |--------------------------------------------------------------------------
    */

    $_SESSION = [];

    if (ini_get("session.use_cookies")) {

        $params = session_get_cookie_params();

        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params["path"],
            $params["domain"],
            $params["secure"],
            $params["httponly"]
        );

    }

    session_destroy();


    /*
    |--------------------------------------------------------------------------
    | Redirect ke login dengan notifikasi
    |--------------------------------------------------------------------------
    */

    header("Location: login.php?deleted=1");
    exit;

}


/*
|--------------------------------------------------------------------------
| Jika gagal
|--------------------------------------------------------------------------
*/

header("Location: profil.php?error=hapus");
exit;

?>
