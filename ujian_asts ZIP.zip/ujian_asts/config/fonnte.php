<?php

$FONNTE_TOKEN = "LTQtMENikJ63TePxduPu";

function kirimWhatsApp($target, $pesan)
{
    global $FONNTE_TOKEN;

    if (empty($target)) {
        return [
            "status" => false,
            "message" => "Nomor WhatsApp kosong."
        ];
    }

    if (empty($FONNTE_TOKEN)) {
        return [
            "status" => false,
            "message" => "Token Fonnte belum diisi."
        ];
    }

    $target = preg_replace('/[^0-9]/', '', $target);

    $data = [
        "target" => $target,
        "message" => $pesan,
        "countryCode" => "62"
    ];

    $curl = curl_init();

    curl_setopt_array($curl, [
        CURLOPT_URL => "https://api.fonnte.com/send",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $data,
        CURLOPT_HTTPHEADER => [
            "Authorization: " . $FONNTE_TOKEN
        ],
        CURLOPT_TIMEOUT => 30
    ]);

    $response = curl_exec($curl);

    if ($response === false) {
        $error = curl_error($curl);
        curl_close($curl);

        return [
            "status" => false,
            "message" => $error
        ];
    }

    curl_close($curl);

    return json_decode($response, true);
}