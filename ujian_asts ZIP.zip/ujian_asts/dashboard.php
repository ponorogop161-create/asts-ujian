<?php

session_start();

if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

if ($_SESSION['role'] === 'admin') {
    header("Location: admin/dashboard.php");
    exit;
}

$pageTitle = "Dashboard Saya - Ujian ASTS";
$activePage = "Dashboard";

require_once "config/koneksi.php";

include "header.php";

require_once "config/koneksi.php";

$id = $_SESSION['id'];

$stmt = $conn->prepare("
    SELECT id, name, nisn, ttl, gender, email, no_hp, address, role, created_at
    FROM users
    WHERE id = ?
    LIMIT 1
");

$stmt->bind_param("i", $id);
$stmt->execute();

$user = $stmt->get_result()->fetch_assoc();

$notif = $_SESSION['notif'] ?? null;
unset($_SESSION['notif']);


/* Statistik */

$totalSiswa = $conn->query("
    SELECT COUNT(*) AS total
    FROM users
    WHERE role = 'user'
")->fetch_assoc()['total'];

$totalLaki = $conn->query("
    SELECT COUNT(*) AS total
    FROM users
    WHERE role = 'user'
    AND UPPER(gender) = 'MALE'
")->fetch_assoc()['total'];

$totalPerempuan = $conn->query("
    SELECT COUNT(*) AS total
    FROM users
    WHERE role = 'user'
    AND UPPER(gender) = 'FEMALE'
")->fetch_assoc()['total'];


/* Siswa terbaru */

$terbaru = $conn->query("
    SELECT id, name, email, gender, created_at
    FROM users
    WHERE role = 'user'
    ORDER BY id DESC
    LIMIT 5
");


/* Persentase */

$persenLaki = $totalSiswa > 0
    ? round(($totalLaki / $totalSiswa) * 100)
    : 0;

$persenPerempuan = $totalSiswa > 0
    ? round(($totalPerempuan / $totalSiswa) * 100)
    : 0;

?>

<!DOCTYPE html>

<html lang="id">

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Dashboard - Ujian ASTS</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, Helvetica, sans-serif;
    background: #f1f5f7;
    color: #102530;
}


/* NAVBAR */

.navbar {
    height: 70px;
    background: #ffffff;
    border-bottom: 1px solid #dde6ea;

    display: flex;
    align-items: center;
    justify-content: space-between;

    padding: 0 35px;

    position: sticky;
    top: 0;
    z-index: 10;
}

.brand {
    text-decoration: none;
    color: #0b6e6e;
    font-size: 21px;
    font-weight: bold;
}

.nav-menu {
    display: flex;
    align-items: center;
    gap: 5px;
}

.nav-menu a {
    text-decoration: none;
    color: #425563;
    padding: 10px 13px;
    border-radius: 8px;
    font-size: 14px;
}

.nav-menu a:hover,
.nav-menu a.active {
    background: #e0f0ee;
    color: #0b6e6e;
}

.nav-menu .logout {
    color: #a4262c;
    background: #fbe7e7;
}


/* CONTAINER */

.container {
    max-width: 1250px;
    margin: auto;
    padding: 35px 25px 60px;
}


/* WELCOME */

.welcome {
    display: flex;
    justify-content: space-between;
    align-items: center;

    background: linear-gradient(
        135deg,
        #0b6e6e,
        #168b87
    );

    color: white;

    padding: 30px;
    border-radius: 18px;

    margin-bottom: 25px;

    box-shadow:
        0 10px 25px rgba(11,110,110,.15);
}

.welcome h1 {
    margin: 0 0 8px;
    font-size: 28px;
}

.welcome p {
    margin: 0;
    opacity: .9;
}

.welcome-icon {
    font-size: 65px;
}


/* NOTIFIKASI */

.notif {
    background: #e0f0ee;
    color: #075d5d;

    border: 1px solid #b9ded9;

    padding: 14px 18px;

    border-radius: 10px;

    margin-bottom: 25px;

    font-weight: 600;
}


/* STATISTIK */

.section-title {
    margin: 30px 0 15px;

    font-size: 20px;
}

.stats {
    display: grid;

    grid-template-columns:
        repeat(3, 1fr);

    gap: 18px;
}

.stat-card {
    background: white;

    border: 1px solid #e0e7ea;

    border-radius: 15px;

    padding: 22px;

    transition: .2s;
}

.stat-card:hover {
    transform: translateY(-3px);

    box-shadow:
        0 8px 20px rgba(0,0,0,.06);
}

.stat-top {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.stat-icon {
    width: 45px;
    height: 45px;

    border-radius: 12px;

    display: flex;
    align-items: center;
    justify-content: center;

    font-size: 22px;

    background: #e0f0ee;
}

.stat-number {
    font-size: 31px;

    font-weight: bold;

    margin-top: 15px;
}

.stat-label {
    color: #687b84;

    margin-top: 4px;

    font-size: 14px;
}


/* MAIN GRID */

.main-grid {
    display: grid;

    grid-template-columns:
        1.6fr 1fr;

    gap: 20px;

    margin-top: 25px;
}


/* PANEL */

.panel {
    background: white;

    border: 1px solid #e0e7ea;

    border-radius: 16px;

    overflow: hidden;
}

.panel-header {
    padding: 20px;

    border-bottom: 1px solid #edf1f2;

    display: flex;

    justify-content: space-between;

    align-items: center;
}

.panel-header h2 {
    margin: 0;

    font-size: 18px;
}

.panel-header a {
    text-decoration: none;

    color: #0b6e6e;

    font-size: 13px;

    font-weight: bold;
}


/* TABLE */

.table-wrap {
    overflow-x: auto;
}

table {
    width: 100%;

    border-collapse: collapse;
}

th {
    text-align: left;

    font-size: 12px;

    color: #71828a;

    background: #f8fafb;

    padding: 12px 18px;
}

td {
    padding: 14px 18px;

    border-top: 1px solid #eef2f3;

    font-size: 13px;
}

.nama-siswa {
    font-weight: bold;
}

.email {
    color: #81929a;

    font-size: 12px;
}

.badge {
    display: inline-block;

    padding: 5px 9px;

    border-radius: 20px;

    font-size: 11px;

    font-weight: bold;
}

.badge.laki {
    background: #e6effa;

    color: #1c4f8f;
}

.badge.perempuan {
    background: #fae9f1;

    color: #95326b;
}


/* PROFILE */

.profile-content {
    padding: 22px;
}

.profile-head {
    display: flex;

    align-items: center;

    gap: 15px;

    margin-bottom: 22px;
}

.avatar {
    width: 60px;
    height: 60px;

    border-radius: 50%;

    background: #e0f0ee;

    display: flex;

    align-items: center;
    justify-content: center;

    font-size: 28px;
}

.profile-name {
    font-size: 18px;

    font-weight: bold;
}

.profile-role {
    margin-top: 4px;

    color: #71828a;

    font-size: 13px;
}

.profile-info {
    display: flex;

    flex-direction: column;

    gap: 12px;
}

.info-row {
    display: flex;

    justify-content: space-between;

    gap: 15px;

    padding-bottom: 11px;

    border-bottom: 1px solid #edf1f2;
}

.info-label {
    color: #7a8b93;

    font-size: 13px;
}

.info-value {
    font-size: 13px;

    font-weight: 600;

    text-align: right;
}


/* QUICK MENU */

.quick {
    margin-top: 25px;

    display: grid;

    grid-template-columns:
        repeat(4, 1fr);

    gap: 15px;
}

.quick a {
    text-decoration: none;

    background: white;

    border: 1px solid #e0e7ea;

    border-radius: 13px;

    padding: 20px;

    color: #102530;

    transition: .2s;
}

.quick a:hover {
    border-color: #0b6e6e;

    transform: translateY(-2px);
}

.quick-icon {
    font-size: 25px;

    margin-bottom: 12px;
}

.quick-title {
    font-weight: bold;

    font-size: 14px;
}

.quick-desc {
    color: #7b8b92;

    font-size: 12px;

    margin-top: 4px;
}


/* FOOTER */

.footer {
    text-align: center;

    color: #84949b;

    font-size: 12px;

    margin-top: 40px;
}


/* RESPONSIVE */

@media(max-width:900px) {

    .main-grid {
        grid-template-columns: 1fr;
    }

    .quick {
        grid-template-columns:
            repeat(2, 1fr);
    }

}

@media(max-width:700px) {

    .navbar {
        height: auto;

        padding: 15px;

        flex-direction: column;

        gap: 12px;
    }

    .nav-menu {
        flex-wrap: wrap;

        justify-content: center;
    }

    .welcome {
        padding: 22px;
    }

    .welcome-icon {
        display: none;
    }

    .stats {
        grid-template-columns: 1fr;
    }

    .quick {
        grid-template-columns: 1fr;
    }

}

</style>

</head>

<body>

<!-- NAVBAR -->


<main class="container">

<!-- NOTIFIKASI -->

<?php if ($notif): ?>

<div class="notif">
✓ <?= htmlspecialchars($notif) ?>
</div>

<?php endif; ?>

<!-- WELCOME -->

<section class="welcome">

<div>

<h1>
Halo, <?= htmlspecialchars($user['name']) ?> 👋
</h1>

<p>
Selamat datang kembali di Dashboard Ujian ASTS.
</p>

</div>

<div class="welcome-icon">
🎓
</div>

</section>

<!-- STATISTIK -->

<h2 class="section-title">
📊 Statistik Siswa
</h2>

<section class="stats">

<div class="stat-card">

<div class="stat-top">

<div>
Total Siswa
</div>

<div class="stat-icon">
👨‍🎓
</div>

</div>

<div class="stat-number">
<?= $totalSiswa ?>
</div>

<div class="stat-label">
Siswa yang terdaftar
</div>

</div>

<div class="stat-card">

<div class="stat-top">

<div>
Laki-laki
</div>

<div class="stat-icon">
👨
</div>

</div>

<div class="stat-number">
<?= $totalLaki ?>
</div>

<div class="stat-label">
<?= $persenLaki ?>% dari seluruh siswa
</div>

</div>

<div class="stat-card">

<div class="stat-top">

<div>
Perempuan
</div>

<div class="stat-icon">
👩
</div>

</div>

<div class="stat-number">
<?= $totalPerempuan ?>
</div>

<div class="stat-label">
<?= $persenPerempuan ?>% dari seluruh siswa
</div>

</div>

</section>

<!-- PANEL UTAMA -->

<section class="main-grid">

<!-- SISWA TERBARU -->

<div class="panel">

<div class="panel-header">

<h2>
👥 Siswa Terbaru
</h2>

<a href="index.php">
Lihat semua →
</a>

</div>

<div class="table-wrap">

<table>

<thead>

<tr>

<th>
Nama
</th>

<th>
Email
</th>

<th>
Gender
</th>

<th>
Tanggal
</th>

</tr>

</thead>

<tbody>

<?php if ($terbaru && $terbaru->num_rows > 0): ?>

<?php while ($siswa = $terbaru->fetch_assoc()): ?>

<tr>

<td>

<div class="nama-siswa">

<?= htmlspecialchars($siswa['name']) ?>

</div>

</td>

<td>

<div class="email">

<?= htmlspecialchars($siswa['email']) ?>

</div>

</td>

<td>

<?php if (strtoupper($siswa['gender']) === 'MALE'): ?>

<span class="badge laki">
Laki-laki
</span>

<?php else: ?>

<span class="badge perempuan">
Perempuan
</span>

<?php endif; ?>

</td>

<td>

<?= date(
    'd/m/Y',
    strtotime($siswa['created_at'])
) ?>

</td>

</tr>

<?php endwhile; ?>

<?php else: ?>

<tr>

<td colspan="4" style="text-align:center">

Belum ada siswa.

</td>

</tr>

<?php endif; ?>

</tbody>

</table>

</div>

</div>

<!-- PROFIL SINGKAT -->

<div class="panel">

<div class="panel-header">

<h2>
👤 Profil Saya
</h2>

<a href="profil.php">
Detail →
</a>

</div>

<div class="profile-content">

<div class="profile-head">

<div class="avatar">
👤
</div>

<div>

<div class="profile-name">
<?= htmlspecialchars($user['name']) ?>
</div>

<div class="profile-role">
Akun <?= htmlspecialchars(ucfirst($user['role'])) ?>
</div>

</div>

</div>

<div class="profile-info">

<div class="info-row">

<div class="info-label">
NISN
</div>

<div class="info-value">
<?= htmlspecialchars($user['nisn']) ?>
</div>

</div>

<div class="info-row">

<div class="info-label">
Email
</div>

<div class="info-value">
<?= htmlspecialchars($user['email']) ?>
</div>

</div>

<div class="info-row">

<div class="info-label">
No. HP
</div>

<div class="info-value">

<?= htmlspecialchars(
    $user['no_hp'] ?: '-'
) ?>

</div>

</div>

<div class="info-row">

<div class="info-label">
Gender
</div>

<div class="info-value">
<?= htmlspecialchars($user['gender']) ?>
</div>

</div>

</div>

</div>

</div>

</section>

<!-- MENU CEPAT -->

<h2 class="section-title">
⚡ Akses Cepat
</h2>

<section class="quick">

<a href="index.php">

<div class="quick-icon">
👨‍🎓
</div>

<div class="quick-title">
Data Siswa
</div>

<div class="quick-desc">
Melihat daftar siswa
</div>

</a>

<a href="profil.php">

<div class="quick-icon">
👤
</div>

<div class="quick-title">
Profil Saya
</div>

<div class="quick-desc">
Melihat informasi akun
</div>

</a>

<a href="edit_profil.php">

<div class="quick-icon">
✏️
</div>

<div class="quick-title">
Edit Profil
</div>

<div class="quick-desc">
Mengubah data pribadi
</div>

</a>

<a href="logout.php">

<div class="quick-icon">
🚪
</div>

<div class="quick-title">
Logout
</div>

<div class="quick-desc">
Keluar dari akun
</div>

</a>

</section>

<div class="footer">

Ujian ASTS © 2026 · Sistem Informasi Data Siswa

</div>

</main>

</body>

</html>
