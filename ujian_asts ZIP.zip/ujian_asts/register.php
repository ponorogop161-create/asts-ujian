<?php

session_start();

require_once "config/koneksi.php";
require_once "config/fonnte.php";

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name     = trim($_POST['name'] ?? '');
    $nisn     = trim($_POST['nisn'] ?? '');
    $ttl      = trim($_POST['ttl'] ?? '');
    $gender   = trim($_POST['gender'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $no_hp    = trim($_POST['no_hp'] ?? '');
    $address  = trim($_POST['address'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';


    /*
    |--------------------------------------------------------------------------
    | Validasi
    |--------------------------------------------------------------------------
    */

    if (
        $name === '' ||
        $nisn === '' ||
        $ttl === '' ||
        $gender === '' ||
        $email === '' ||
        $no_hp === '' ||
        $address === '' ||
        $password === ''
    ) {

        $error = "Semua data wajib diisi.";

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        $error = "Format email tidak valid.";

    } elseif ($password !== $confirm) {

        $error = "Konfirmasi password tidak sama.";

    } elseif (strlen($password) < 6) {

        $error = "Password minimal 6 karakter.";

    } else {


        /*
        |--------------------------------------------------------------------------
        | Cek email
        |--------------------------------------------------------------------------
        */

        $stmt = $conn->prepare("
            SELECT id
            FROM users
            WHERE email = ?
            LIMIT 1
        ");

        $stmt->bind_param("s", $email);
        $stmt->execute();

        $cekEmail = $stmt->get_result();


        if ($cekEmail->num_rows > 0) {

            $error = "Email sudah terdaftar.";

        } else {


            /*
            |--------------------------------------------------------------------------
            | Cek NISN
            |--------------------------------------------------------------------------
            */

            $stmt = $conn->prepare("
                SELECT id
                FROM users
                WHERE nisn = ?
                LIMIT 1
            ");

            $stmt->bind_param("s", $nisn);
            $stmt->execute();

            $cekNisn = $stmt->get_result();


            if ($cekNisn->num_rows > 0) {

                $error = "NISN sudah terdaftar.";

            } else {


                /*
                |--------------------------------------------------------------------------
                | Password Hash
                |--------------------------------------------------------------------------
                */

                $passwordHash = password_hash(
                    $password,
                    PASSWORD_DEFAULT
                );


                /*
                |--------------------------------------------------------------------------
                | Role otomatis USER
                |--------------------------------------------------------------------------
                */

                $role = "user";


                /*
                |--------------------------------------------------------------------------
                | Simpan ke database
                |--------------------------------------------------------------------------
                */

                $stmt = $conn->prepare("
                    INSERT INTO users
                    (
                        name,
                        nisn,
                        ttl,
                        gender,
                        email,
                        no_hp,
                        role,
                        address,
                        password
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");

                $stmt->bind_param(
                    "sssssssss",
                    $name,
                    $nisn,
                    $ttl,
                    $gender,
                    $email,
                    $no_hp,
                    $role,
                    $address,
                    $passwordHash
                );


                if ($stmt->execute()) {

                    $idBaru = $stmt->insert_id;


                    /*
                    |--------------------------------------------------------------------------
                    | Notifikasi WhatsApp
                    |--------------------------------------------------------------------------
                    */

                    $pesan =
                        "🔔 PENDAFTARAN UJIAN ASTS\n\n" .
                        "Halo " . $name . ",\n\n" .
                        "Pendaftaran akun Anda berhasil.\n\n" .
                        "Nama: " . $name . "\n" .
                        "NISN: " . $nisn . "\n" .
                        "Email: " . $email . "\n\n" .
                        "Akun Anda sekarang dapat digunakan untuk login ke sistem Ujian ASTS.\n\n" .
                        "Terima kasih.";


                    $hasilWA = kirimWhatsApp(
                        $no_hp,
                        $pesan
                    );


                    /*
                    |--------------------------------------------------------------------------
                    | Notifikasi website
                    |--------------------------------------------------------------------------
                    */

                    $_SESSION['notif'] =
                        "Pendaftaran berhasil. Silakan login.";


                    /*
                    |--------------------------------------------------------------------------
                    | Simpan hasil WA sementara
                    |--------------------------------------------------------------------------
                    */

                    $_SESSION['register_wa'] = $hasilWA;


                    /*
                    |--------------------------------------------------------------------------
                    | Redirect login
                    |--------------------------------------------------------------------------
                    */

                    header("Location: login.php");
                    exit;

                } else {

                    $error =
                        "Pendaftaran gagal. Silakan coba lagi.";
                }
            }
        }
    }
}

?>

<!DOCTYPE html>

<html lang="id">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>Pendaftaran - Ujian ASTS</title>


<style>

    * {
        box-sizing: border-box;
    }

    body {
        margin: 0;
        min-height: 100vh;
        background: #eef2f4;
        font-family: Arial, sans-serif;
        padding: 40px 15px;
    }

    .box {
        max-width: 700px;
        margin: auto;
        background: #ffffff;
        border-radius: 18px;
        padding: 35px;
        box-shadow: 0 15px 40px rgba(0,0,0,.10);
    }

    .logo {
        text-align: center;
        font-size: 42px;
    }

    h1 {
        text-align: center;
        color: #102530;
        margin-bottom: 5px;
    }

    .subtitle {
        text-align: center;
        color: #71828a;
        margin-bottom: 30px;
    }

    .error {
        background: #fbe7e7;
        color: #a4262c;
        padding: 12px;
        border-radius: 9px;
        margin-bottom: 20px;
    }

    .grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 18px;
    }

    .field {
        margin-bottom: 4px;
    }

    .full {
        grid-column: 1 / -1;
    }

    label {
        display: block;
        font-weight: 600;
        margin-bottom: 7px;
        color: #263b45;
    }

    input,
    select,
    textarea {
        width: 100%;
        padding: 12px;
        border: 1px solid #d8e1e5;
        border-radius: 9px;
        font-size: 14px;
        font-family: inherit;
    }

    textarea {
        min-height: 90px;
        resize: vertical;
    }

    input:focus,
    select:focus,
    textarea:focus {
        outline: 2px solid #0b6e6e;
        border-color: #0b6e6e;
    }

    .submit {
        width: 100%;
        padding: 13px;
        border: 0;
        border-radius: 9px;
        background: #0b6e6e;
        color: white;
        font-size: 15px;
        font-weight: bold;
        cursor: pointer;
        margin-top: 10px;
    }

    .submit:hover {
        background: #095a5a;
    }

    .login {
        text-align: center;
        margin-top: 20px;
        color: #71828a;
    }

    .login a {
        color: #0b6e6e;
        font-weight: bold;
        text-decoration: none;
    }

    @media(max-width:650px) {

        .box {
            padding: 25px 20px;
        }

        .grid {
            grid-template-columns: 1fr;
        }

        .full {
            grid-column: auto;
        }

    }

</style>

</head>

<body>

<div class="box">

<div class="logo">
    👨‍🎓
</div>

<h1>
    Pendaftaran Akun
</h1>

<div class="subtitle">
    Buat akun baru untuk mengakses Ujian ASTS
</div>


<?php if ($error): ?>

    <div class="error">
        <?= htmlspecialchars($error) ?>
    </div>

<?php endif; ?>


<form method="POST">

    <div class="grid">


        <div class="field full">

            <label>
                Nama Lengkap
            </label>

            <input
                type="text"
                name="name"
                placeholder="Masukkan nama lengkap"
                value="<?= htmlspecialchars($_POST['name'] ?? '') ?>"
                required
            >

        </div>


        <div class="field">

            <label>
                NISN
            </label>

            <input
                type="text"
                name="nisn"
                placeholder="Masukkan NISN"
                value="<?= htmlspecialchars($_POST['nisn'] ?? '') ?>"
                required
            >

        </div>


        <div class="field">

            <label>
                Tempat, Tanggal Lahir
            </label>

            <input
                type="text"
                name="ttl"
                placeholder="Contoh: Sumenep, 12 Mei 2009"
                value="<?= htmlspecialchars($_POST['ttl'] ?? '') ?>"
                required
            >

        </div>


        <div class="field">

            <label>
                Gender
            </label>

            <select name="gender" required>

                <option value="">
                    Pilih gender
                </option>

                <option
                    value="MALE"
                    <?= ($_POST['gender'] ?? '') === 'MALE' ? 'selected' : '' ?>
                >
                    Laki-laki
                </option>

                <option
                    value="FEMALE"
                    <?= ($_POST['gender'] ?? '') === 'FEMALE' ? 'selected' : '' ?>
                >
                    Perempuan
                </option>

            </select>

        </div>


        <div class="field">

            <label>
                No. HP / WhatsApp
            </label>

            <input
                type="text"
                name="no_hp"
                placeholder="08xxxxxxxxxx"
                value="<?= htmlspecialchars($_POST['no_hp'] ?? '') ?>"
                required
            >

        </div>


        <div class="field full">

            <label>
                Email
            </label>

            <input
                type="email"
                name="email"
                placeholder="contoh@email.com"
                value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                required
            >

        </div>


        <div class="field">

            <label>
                Password
            </label>

            <input
                type="password"
                name="password"
                placeholder="Minimal 6 karakter"
                required
            >

        </div>


        <div class="field">

            <label>
                Konfirmasi Password
            </label>

            <input
                type="password"
                name="confirm_password"
                placeholder="Ulangi password"
                required
            >

        </div>


        <div class="field full">

            <label>
                Alamat
            </label>

            <textarea
                name="address"
                placeholder="Masukkan alamat lengkap"
                required
            ><?= htmlspecialchars($_POST['address'] ?? '') ?></textarea>

        </div>


    </div>


    <button
        type="submit"
        class="submit"
    >
        Daftar Sekarang
    </button>

</form>


<div class="login">

    Sudah punya akun?

    <a href="login.php">
        Login di sini
    </a>

</div>

</div>

</body>

</html>
