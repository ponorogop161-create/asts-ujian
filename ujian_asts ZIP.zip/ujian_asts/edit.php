<?php

include 'koneksi.php';

$id = $_POST['id'];
$name = $_POST['name'];
$nisn = $_POST['nisn'];
$ttl = $_POST['ttl'];
$gender = $_POST['gender'];
$email = $_POST['email'];
$address = $_POST['address'];

$query = "UPDATE users SET
          name = '$name',
          nisn = '$nisn',
          ttl = '$ttl',
          gender = '$gender',
          email = '$email',
          address = '$address'
          WHERE id = '$id'";

if (mysqli_query($koneksi, $query)) {
    echo json_encode([
        "status" => true,
        "message" => "Data berhasil diubah"
    ]);
} else {
    echo json_encode([
        "status" => false,
        "message" => "Data gagal diubah"
    ]);
}
?>