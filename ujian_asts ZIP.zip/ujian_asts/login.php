<?php

session_start();

require_once "config/koneksi.php";
require_once "config/fonnte.php";

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email === '' || $password === '') {

        $error = "Email dan password wajib diisi.";

    } else {

        /*
        |--------------------------------------------------------------------------
        | Cari user berdasarkan email
        |--------------------------------------------------------------------------
        */

        $stmt = $conn->prepare("
            SELECT
                id,
                name,
                nisn,
                ttl,
                gender,
                email,
                no_hp,
                role,
                address,
                password
            FROM users
            WHERE email = ?
            LIMIT 1
        ");

        $stmt->bind_param("s", $email);
        $stmt->execute();

        $result = $stmt->get_result();
        $user = $result->fetch_assoc();


        /*
        |--------------------------------------------------------------------------
        | Cek password
        |--------------------------------------------------------------------------
        */

        if (!$user || !password_verify($password, $user['password'])) {

            $error = "Email atau password salah.";

        } else {

            /*
            |--------------------------------------------------------------------------
            | LOGIN BERHASIL
            |--------------------------------------------------------------------------
            */

            $_SESSION['login'] = true;

            $_SESSION['id'] = $user['id'];

            $_SESSION['username'] = $user['name'];

            $_SESSION['role'] = $user['role'];

            $_SESSION['email'] = $user['email'];


            /*
            |--------------------------------------------------------------------------
            | Notifikasi website
            |--------------------------------------------------------------------------
            */

            $_SESSION['notif'] =
                "Anda berhasil login.";


            /*
            |--------------------------------------------------------------------------
            | NOTIFIKASI WHATSAPP
            |--------------------------------------------------------------------------
            */

            if (!empty($user['no_hp'])) {

                $pesan =
                    "🔔 NOTIFIKASI UJIAN ASTS\n\n" .
                    "Halo " . $user['name'] . ",\n\n" .
                    "Anda berhasil login ke sistem Ujian ASTS.\n\n" .
                    "Email: " . $user['email'] . "\n" .
                    "Waktu: " . date('d-m-Y H:i:s') . "\n\n" .
                    "Jika Anda tidak melakukan login ini, segera hubungi administrator.";

                $hasilWA = kirimWhatsApp(
                    $user['no_hp'],
                    $pesan
                );


                /*
                |--------------------------------------------------------------------------
                | Simpan hasil WA untuk debugging
                |--------------------------------------------------------------------------
                */

                $_SESSION['wa_login_status'] = $hasilWA;
            }


            /*
            |--------------------------------------------------------------------------
            | Redirect berdasarkan role
            |--------------------------------------------------------------------------
            */

            if ($user['role'] === 'admin') {

                header("Location: admin/dashboard.php");
                exit;

            } else {

                header("Location: dashboard.php");
                exit;
            }
        }
    }
}

?>

<!DOCTYPE html>

<html lang="id">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>Login - Ujian ASTS</title>

<style>

    * {
        box-sizing: border-box;
    }

    body {
        margin: 0;
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        background: #eef2f4;
        font-family: Arial, sans-serif;
    }

    .login-box {
        width: 400px;
        max-width: 92%;
        background: white;
        padding: 35px;
        border-radius: 18px;
        box-shadow: 0 15px 40px rgba(0,0,0,.10);
    }

    .logo {
        text-align: center;
        font-size: 42px;
        margin-bottom: 10px;
    }

    h1 {
        text-align: center;
        margin: 0;
        color: #102530;
    }

    .subtitle {
        text-align: center;
        color: #71828a;
        margin-bottom: 25px;
    }

    label {
        display: block;
        margin-bottom: 6px;
        font-weight: 600;
        color: #263b45;
    }

    input {
        width: 100%;
        padding: 12px;
        border: 1px solid #d8e1e5;
        border-radius: 9px;
        margin-bottom: 18px;
        font-size: 15px;
    }

    input:focus {
        outline: 2px solid #0b6e6e;
        border-color: #0b6e6e;
    }

    button {
        width: 100%;
        padding: 13px;
        border: 0;
        border-radius: 9px;
        background: #0b6e6e;
        color: white;
        font-size: 15px;
        font-weight: bold;
        cursor: pointer;
    }

    button:hover {
        background: #095a5a;
    }

    .error {
        background: #fbe7e7;
        color: #a4262c;
        padding: 11px;
        border-radius: 8px;
        margin-bottom: 18px;
        font-size: 14px;
    }

</style>

</head>

<body>

<div class="login-box">

<div class="logo">
    👨‍🎓
</div>

<h1>Ujian ASTS</h1>

<div class="subtitle">
    Silakan login ke akun Anda
</div>


<?php if ($error): ?>

    <div class="error">
        <?= htmlspecialchars($error) ?>
    </div>

<?php endif; ?>


<form method="POST">

    <label>
        Email
    </label>

    <input
        type="email"
        name="email"
        placeholder="Masukkan email"
        required
        autocomplete="email"
    >


    <label>
        Password
    </label>

    <input
        type="password"
        name="password"
        placeholder="Masukkan password"
        required
        autocomplete="current-password"
    >


    <button type="submit">
        Login
    </button>

    <p style="text-align:center;margin-top:20px;">
    Belum punya akun?
    <a href="register.php"
       style="color:#0b6e6e;font-weight:bold;">
        Daftar sekarang
    </a>
</p>

</form>

</div>

</body>

</html>
