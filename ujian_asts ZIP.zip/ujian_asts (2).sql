-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 01, 2026 at 08:02 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ujian_asts`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', '827ccb0eea8a706c4c34a16891f84e7b'),
(2, 'admin2', '0192023a7bbd73250516f069df18b500');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `message` varchar(255) NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `nisn` varchar(20) NOT NULL,
  `ttl` varchar(100) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `no_hp` varchar(20) DEFAULT NULL,
  `role` enum('admin','user') NOT NULL DEFAULT 'user',
  `address` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `nisn`, `ttl`, `gender`, `email`, `no_hp`, `role`, `address`, `created_at`, `password`) VALUES
(1, 'Leanne Grahamm', '12313155134', 'PONOROGO, 12 Agustus 2011', 'MALE', 'Sincere@april.biz', NULL, 'user', 'Kulas Light, Apt. 556, Gwenborough, 92998-3876', '2026-10-01 01:25:35', NULL),
(3, 'Clementine Bauch', '632641362', 'PONOROGO, 12 Agustus 2010', 'MALE', 'Nathan@yesenia.net', NULL, 'user', 'Douglas Extension, Suite 847, McKenziehaven, 59590-4157', '2026-10-01 01:25:35', NULL),
(4, 'Patricia Lebsack', '782346125', 'PONOROGO, 12 Agustus 2010', 'FEMALE', 'Julianne@yesenia.net', NULL, 'user', 'Hoeger Mall, Apt. 692, South Elvis, 53919-4257', '2026-10-01 01:25:35', NULL),
(6, 'dani', '166565', 'Ponorogo, 4 Maret 2009', 'MALE', 'dani@gmail.com', NULL, 'user', 'ponorogo', '2026-10-01 01:25:35', NULL),
(20, 'Administrator', '7675675757', 'Sumenep, 01 Januari 2000', 'MALE', 'admin@gmail.com', '082257013571', 'admin', 'Administrator Ujian ASTS', '2026-10-01 03:11:09', '$2y$10$hD9D2ygjbbcHHWBO0/VEA.KZUkrmCJWWvKCrvCjNBvkiOUR0TlH42'),
(22, '12. DIMAS RIANG ILHAM SAPUTRAaa', '324232666', 'PONOROGO,5 Februari 1909', 'MALE', 'dris220609@gmail.com', '089655028090', 'user', 'zwi', '2026-10-01 04:03:36', '$2y$10$CGvZAEOPAhDyDk3Gi3Dr9Op95w8etKercQglakaLzmTN.DKyWNlT6'),
(24, 'Edo Kempleng', '876876887', 'PONOROGO,5 Februari 1909', 'MALE', 'edo@gmail.com', '089655028090', 'user', 'SLAONG', '2026-10-01 04:09:26', '$2y$10$gpeA31phyhPe47OjjZgkiexCbpxWDiK3LL5VzE/e676H768znVgXi');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
